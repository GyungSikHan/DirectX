#include "pch.h"
#include "MeshRenderer.h"

#include "Game.h"
#include "Camera/Camera.h"

MeshRenderer::MeshRenderer(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext) : Super (ComponentType::MeshRenderer)
{
	device = Device;

	//Create Geometry
	geometry = make_shared<Geometry<VertexTextureData>>();
	GeometryHelper::CreateRectangle(geometry);

	//VertexBuffer
	vertexBuffer = make_shared<VertexBuffer>(device);
	vertexBuffer->Create<VertexTextureData>(geometry->GetVertices());

	//IndexBuffer
	indexBuffer = make_shared<IndexBuffer>(device);
	indexBuffer->Create(geometry->GetIndices());

	//Create VS
	vertexShader = make_shared<VertexShader>(device);
	vertexShader->Create(L"Default.hlsl", "VS", "vs_5_0");

	//CreateInputLayout
	inputLayout = make_shared<InputLayout>(device);
	inputLayout->Create(VertexTextureData::descs, vertexShader->GetBlob());

	//CreatePS
	pixelShader = make_shared<PixelShader>(device);
	pixelShader->Create(L"Default.hlsl", "PS", "ps_5_0");

	//Rasterrize
	rs = make_shared<Rasterizer>(device);
	rs->Create();

	//CreateBlendState
	blend = make_shared<BlendState>(device);
	blend->Create();

	//CreateCameraBuffer
	m_pCameraBuffer = make_shared<ConstantBuffer<CameraData>>(device, DeviceContext);
	m_pCameraBuffer->Create();

	//CreateConstantBuffer
	m_pTransformBuffer = make_shared<ConstantBuffer<TransformData>>(device, DeviceContext);
	m_pTransformBuffer->Create();
	//CreateSRV
	srv = make_shared<Texture>(device);
	srv->Create(L"IMG_1018.HEIC");
	//CreateSamplerState
	sampler = make_shared<SamplerState>(device);
	sampler->Create();
}

MeshRenderer::~MeshRenderer()
{
}

void MeshRenderer::Update()
{
	Component::Update();

	m_cCameraData.View = Camera::m_mMatView;
	m_cCameraData.Projection = Camera::m_mProjection;
		//Matrix::Identity;
		//Matrix::Identity; 
	m_pCameraBuffer->CopyData(m_cCameraData);

	transformData.World = GetTransform()->GetWorldMatrix();
	m_pTransformBuffer->CopyData(transformData);

	Render(GGame->GetPipline());
}

void MeshRenderer::Render(shared_ptr<Pipeline> Pipeline)
{
	//IA - VS - RS - PS - OM

	PipelineInfo info;

	info.inputLayout = inputLayout;
	info.vertexShader = vertexShader;
	info.pixelShader = pixelShader;
	info.rs = rs;
	info.blend = blend;

	Pipeline->UpdatePipeline(info);

	Pipeline->SetVertexBuffer(vertexBuffer);
	Pipeline->SetIndexBuffer(indexBuffer);

	Pipeline->ConstantBuffer(0, EVertexShader, m_pCameraBuffer);
	Pipeline->ConstantBuffer(1, EVertexShader, m_pTransformBuffer);

	Pipeline->SetTexture(0, EPixelShader, srv);
	Pipeline->SetSamplerState(0, EPixelShader, sampler);

	Pipeline->DrawIndexed(geometry->GetIndexCount(), 0, 0);
}
