#include "pch.h"
#include "SceneManager.h"
#include "GameObject.h"
#include "Camera/Camera.h"

SceneManager::SceneManager(shared_ptr<Graphics> graphics)
	:m_pGraphics(graphics)
{
}

void SceneManager::Init()
{
	if(m_pActiveScene == nullptr)
		return;

	m_pActiveScene->Awake();
	m_pActiveScene->Start();
}

void SceneManager::Update()
{
	if (m_pActiveScene == nullptr)
		return;

	m_pActiveScene->Update();
	m_pActiveScene->LateUpdate();

	m_pActiveScene->FixedUpdate();
}

void SceneManager::LoadScene(wstring sceneName)
{
	m_pActiveScene = LoadTestScene();
	Init();
}


shared_ptr<Scene> SceneManager::LoadTestScene()
{
	//���� ������ Scene�� �����ؼ� ������ �� �ְ� ������ ������
	//���� �ܰ迡���� �ϳ��� Ư�� Scene�� ���� �� ���̴�

	shared_ptr<Scene> scene = make_shared<Scene>();
	
	//Camera
	shared_ptr<GameObject> m_pCamera = make_shared<GameObject>(m_pGraphics->GetDevice(), m_pGraphics->GetDeviceContext());
	{
		m_pCamera->GetOrAddTransform();
		m_pCamera->AddComponent(make_shared<Camera>());
		scene->AddGameObject(m_pCamera);
	}

	//monster
	shared_ptr<GameObject> m_pMonster = make_shared<GameObject>(m_pGraphics->GetDevice(), m_pGraphics->GetDeviceContext());
	{
		m_pMonster->GetOrAddTransform();
		m_pMonster->AddComponent(make_shared<MeshRenderer>(m_pGraphics->GetDevice(), m_pGraphics->GetDeviceContext()));
		//m_pMonster->GetTransform()->SetScale(Vec3(100.0f, 100.0f, 100.0f));
		scene->AddGameObject(m_pMonster);
	}

	return scene;
}
