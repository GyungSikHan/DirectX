#include "pch.h"
#include "Game.h"
#include "Camera/Camera.h"
#include "SceneManager.h"

unique_ptr<Game> GGame = make_unique < Game >();

Game::Game()
{
}

Game::~Game()
{
	graphics.reset();
	
}

void Game::Init(HWND hWnd)
{
	hwnd = hWnd;
	
	graphics = make_shared<Graphics>(hwnd);
	pipeline = make_shared<Pipeline>(graphics->GetDeviceContext());
	m_pScene = make_shared<SceneManager>(graphics);

	SCENE->LoadScene(L"Test");
}

void Game::Update()
{
	graphics->RenderBegin();
	SCENE->Update();
	graphics->RenderEnd();
}

void Game::Render()
{
}
