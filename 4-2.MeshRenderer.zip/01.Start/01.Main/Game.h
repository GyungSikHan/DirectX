#pragma once
#include "GameObject.h"

class Game
{
public:
	Game();
	~Game();

public:
	void Init(HWND hWnd);
	void Update();
	void Render();

private:
	HWND hwnd;
	shared_ptr<Graphics> graphics;
	shared_ptr<Pipeline> pipeline;

	shared_ptr<GameObject> m_pMonster;
	shared_ptr<GameObject> m_pCamera;
};

