#pragma once
#include "Camera.h"
#include "MeshRenderer.h"

class MonoBehaviour;

class GameObject : public enable_shared_from_this<GameObject>
{
public:
	GameObject(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext);
	~GameObject();

	void Awake();
	void Start();
	void Update();
	void LateUpdate();
	void FixedUpdate();

	shared_ptr<Component> GetFixedComponent(ComponentType type);
	shared_ptr<Transform> GetTransform();
	shared_ptr<Camera> GetCamera();
	shared_ptr<MeshRenderer> GetMeshRenderer();

	shared_ptr<Transform> GetOrAddTransform();
	void AddComponent(shared_ptr<Component> component);
	
private:
	ComPtr<ID3D11Device> device;

	
protected:
	array<shared_ptr<Component>, FIXED_COMPONENT_COUNT> m_aComponents;
	vector<shared_ptr<MonoBehaviour>> m_vScripts;
};


