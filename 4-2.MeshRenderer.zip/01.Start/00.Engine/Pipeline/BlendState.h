#pragma once

class BlendState
{
public:
	BlendState(ComPtr<ID3D11Device> Device);
	~BlendState();

	void Create();
	ComPtr<ID3D11BlendState> GetComPtr() { return blend; }
	float* GetBlendFactor() { return &blendFactor; }
	uint32 GetSampleMask() { return sampleMask; }

private:
	ComPtr<ID3D11Device> device;
	ComPtr<ID3D11BlendState> blend;
	float blendFactor = 0.0f;
	uint32 sampleMask = 0xFFFFFFFF;
};