#include "pch.h"
#include "Graphics.h"

Graphics::Graphics(HWND hWnd)
{
	hwnd = hWnd;

	CreateDeviceAndSpwaChain();
	CreateRenderTargetView();
	SetViewport();
}

Graphics::~Graphics()
{
}

void Graphics::RenderBegin()
{
	deviceContext->OMSetRenderTargets(1, renderTargetView.GetAddressOf(), nullptr);

	deviceContext->ClearRenderTargetView(renderTargetView.Get(), clearColor);
	deviceContext->RSSetViewports(1, &viewport);
}

void Graphics::RenderEnd()
{
	HRESULT hr = swapChain->Present(1, 0);
	CHECK(hr);
}

void Graphics::CreateDeviceAndSpwaChain()
{
	DXGI_SWAP_CHAIN_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	{
		desc.BufferDesc.Width = GWinSizeX;
		desc.BufferDesc.Height = GWinSizeY;
		desc.BufferDesc.RefreshRate.Numerator = 60;
		desc.BufferDesc.RefreshRate.Denominator = 1;
		desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
		desc.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
		desc.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
		desc.SampleDesc.Count = 1;
		desc.SampleDesc.Quality = 0;
		desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
		desc.BufferCount = 1;
		desc.OutputWindow = hwnd;

		desc.Windowed = true;
		desc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
	}

	HRESULT hr = ::D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &desc, swapChain.GetAddressOf(), device.GetAddressOf(), nullptr, deviceContext.GetAddressOf());

	CHECK(hr);
}


void Graphics::CreateRenderTargetView()
{
	HRESULT hr;

	ComPtr<ID3D11Texture2D> backBuffer{};
	hr = swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)backBuffer.GetAddressOf());
	CHECK(hr);
	device->CreateRenderTargetView(backBuffer.Get(), nullptr, renderTargetView.GetAddressOf());
}

void Graphics::SetViewport()
{
	viewport.TopLeftX = 0.0f;
	viewport.TopLeftY = 0.0f;
	viewport.Width = static_cast<float>(GWinSizeX);
	viewport.Height = static_cast<float>(GWinSizeY);
	viewport.MinDepth = 0.0f;
	viewport.MaxDepth = 1.0f;
}
