#pragma once
class VertexShader : public Shader
{
	using Super = Shader;
public:
	VertexShader(ComPtr<ID3D11Device> Device);
	~VertexShader();

	ComPtr<ID3D11VertexShader> GetComPtr() { return vertexShader; }

	void Create(const wstring& Path, const string& Name, const string& version) override;

protected:
	ComPtr<ID3D11VertexShader> vertexShader{};
};
