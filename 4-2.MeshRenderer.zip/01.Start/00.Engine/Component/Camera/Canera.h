#pragma once
#include "Component.h"
class Class :
    public Component
{
};

