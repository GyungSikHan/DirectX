#include "pch.h"
#include "Game.h"
#include "Camera.h"

Game::Game()
{
}

Game::~Game()
{
	graphics.reset();
	
}

void Game::Init(HWND hWnd)
{
	hwnd = hWnd;
	
	graphics = make_shared<Graphics>(hwnd);
	pipeline = make_shared<Pipeline>(graphics->GetDeviceContext());
	m_pMonster = make_shared<GameObject>(graphics->GetDevice(), graphics->GetDeviceContext());
	{
		m_pMonster->GetOrAddTransform();
	}

	m_pCamera = make_shared<GameObject>(graphics->GetDevice(), graphics->GetDeviceContext());
	{
		m_pCamera->GetOrAddTransform();
		m_pCamera->AddComponent(make_shared<Camera>());
	}
}

void Game::Update()
{
	m_pMonster->Update();
	m_pCamera->Update();
}

void Game::Render()
{
	graphics->RenderBegin();

	m_pMonster->Rneder(pipeline);
	
	graphics->RenderEnd();
}
