#pragma once
#include "Component.h"

enum class ProjectionType
{
	Perspective,//���� ����
	Orthographic,//���� ����
};

class Camera : public Component
{
public:
	Camera();
	~Camera();

	virtual void Update() override;

	void SetProjectionType(ProjectionType type);
	ProjectionType GetProjectionType() { return m_eType; }

	void UpdateMatrix();

private:
	ProjectionType m_eType = ProjectionType::Orthographic;

public:
	static Matrix m_mMatView;
	static Matrix m_mProjection;
};


