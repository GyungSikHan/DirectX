#include "pch.h"
#include "GameObject.h"
#include "MonoBehaviour.h"
#include "Transform.h"

GameObject::GameObject(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext)
	:device(Device)
{
	//Create Geometry
	geometry = make_shared<Geometry<VertexTextureData>>();
	GeometryHelper::CreateRectangle(geometry);
	
	//VertexBuffer
	vertexBuffer = make_shared<VertexBuffer>(device);
	vertexBuffer->Create<VertexTextureData>(geometry->GetVertices());
	
	//IndexBuffer
	indexBuffer = make_shared<IndexBuffer>(device);
	indexBuffer->Create(geometry->GetIndices());

	//Create VS
	vertexShader = make_shared<VertexShader>(device);
	vertexShader->Create(L"Default.hlsl", "VS", "vs_5_0");

	//CreateInputLayout
	inputLayout = make_shared<InputLayout>(device);
	inputLayout->Create(VertexTextureData::descs, vertexShader->GetBlob());

	//CreatePS
	pixelShader = make_shared<PixelShader>(device);
	pixelShader->Create(L"Default.hlsl", "PS", "ps_5_0");

	//Rasterrize
	rs = make_shared<Rasterizer>(device);
	rs->Create();

	//CreateBlendState
	blend = make_shared<BlendState>(device);
	blend->Create();

	//CreateConstantBuffer
	constantBuffer = make_shared<ConstantBuffer<TransformData>>(device, DeviceContext);
	constantBuffer->Create();
	//CreateSRV
	srv = make_shared<Texture>(device);
	srv->Create(L"IMG_0424.png");
	//CreateSamplerState
	sampler = make_shared<SamplerState>(device);
	sampler->Create();
}

GameObject::~GameObject()
{
}

void GameObject::Awake()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->Awake();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->Awake();
}

void GameObject::Start()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->Start();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->Start();
}

void GameObject::Update()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->Update();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->Update();

	transformData.World = GetOrAddTransform()->GetWorldMatrix();

	constantBuffer->CopyData(transformData);
}

void GameObject::LateUpdate()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->LateUpdate();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->LateUpdate();
}

void GameObject::FixedUpdate()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->FixedUpdate();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->FixedUpdate();
}

shared_ptr<Component> GameObject::GetFixedComponent(ComponentType type)
{
	uint8 index = static_cast<uint8>(type);
	assert(index < FIXED_COMPONENT_COUNT);
	return m_aComponents[index];
}

shared_ptr<Transform> GameObject::GetTransform()
{
	shared_ptr<Component> component = GetFixedComponent(ComponentType::Transform);
	return static_pointer_cast<Transform>(component);
}

shared_ptr<Transform> GameObject::GetOrAddTransform()
{
	if(GetTransform() == nullptr)
	{
		shared_ptr<Transform>transform = make_shared<Transform>();
		AddComponent(transform);
	}

	return GetTransform();
}

void GameObject::AddComponent(shared_ptr<Component> component)
{
	component->SetGameObject(shared_from_this());
	uint8 index = static_cast<uint8>(component->GetType());
	if (index < FIXED_COMPONENT_COUNT)
		m_aComponents[index] = component;
	else
		m_vScripts.push_back(dynamic_pointer_cast<MonoBehaviour>(component));
}

void GameObject::Rneder(shared_ptr<Pipeline> Pipeline)
{
	//IA - VS - RS - PS - OM

	PipelineInfo info;

	info.inputLayout = inputLayout;
	info.vertexShader = vertexShader;
	info.pixelShader = pixelShader;
	info.rs = rs;
	info.blend = blend;

	Pipeline->UpdatePipeline(info);

	Pipeline->SetVertexBuffer(vertexBuffer);
	Pipeline->SetIndexBuffer(indexBuffer);
	Pipeline->ConstantBuffer(0, EVertexShader, constantBuffer);
	Pipeline->SetTexture(0, EPixelShader, srv);
	Pipeline->SetSamplerState(0, EPixelShader, sampler);
	
	Pipeline->DrawIndexed(geometry->GetIndexCount(), 0, 0);
}
