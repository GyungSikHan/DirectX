#include "pch.h"
#include "SceneManager.h"

#include "CameraMove.h"
#include "Game.h"
#include "Resource/ResourceMGR.h"
#include "GameObject.h"
#include "Animation/Animator.h"
#include "Camera/Camera.h"
#include "Resource/Mesh.h"

SceneManager::SceneManager(shared_ptr<Graphics> graphics)
	:m_pGraphics(graphics)
{
}

void SceneManager::Init()
{
	if (m_pActiveScene == nullptr)
		return;

	m_pActiveScene->Awake();
	m_pActiveScene->Start();
}

void SceneManager::Update()
{
	if (m_pActiveScene == nullptr)
		return;

	m_pActiveScene->Update();
	m_pActiveScene->LateUpdate();

	m_pActiveScene->FixedUpdate();
}

void SceneManager::LoadScene(wstring sceneName)
{
	m_pActiveScene = LoadTestScene();
	Init();
}


shared_ptr<Scene> SceneManager::LoadTestScene()
{
	//���� ������ Scene�� �����ؼ� ������ �� �ְ� ������ ������
	//���� �ܰ迡���� �ϳ��� Ư�� Scene�� ���� �� ���̴�

	shared_ptr<Scene> scene = make_shared<Scene>();

	//Camera
	{
		shared_ptr<GameObject> m_pCamera = make_shared<GameObject>(m_pGraphics->GetDevice(), m_pGraphics->GetDeviceContext());
		{
			m_pCamera->GetOrAddTransform();
			m_pCamera->AddComponent(make_shared<Camera>());
			scene->AddGameObject(m_pCamera);
		}
		{
			m_pCamera->AddComponent(make_shared<CameraMove>());
		}
	}

	//monster
	{
		shared_ptr<GameObject> m_pMonster = make_shared<GameObject>(m_pGraphics->GetDevice(), m_pGraphics->GetDeviceContext());
		{
			m_pMonster->GetOrAddTransform();
			shared_ptr<MeshRenderer> meshRenderer = make_shared<MeshRenderer>(m_pGraphics->GetDevice(), m_pGraphics->GetDeviceContext());
			m_pMonster->AddComponent(meshRenderer);

			shared_ptr<Material> material = RESOURCES->Get<Material>(L"Default");
			meshRenderer->SetMaterial(material);

			shared_ptr<Mesh> mesh = RESOURCES->Get<Mesh>(L"Rectangle");
			meshRenderer->SetMesh(mesh);
		}
		{
			shared_ptr<Animator> animator = make_shared<Animator>();
			m_pMonster->AddComponent(animator);
			shared_ptr<Animation> anim = GGame->GetResourceMGR()->Get<Animation>(L"SnakeAnim");
			animator->SetAnimation(anim);
		}
		scene->AddGameObject(m_pMonster);
	}

	//monster
	{
		shared_ptr<GameObject> m_pMonster = make_shared<GameObject>(m_pGraphics->GetDevice(), m_pGraphics->GetDeviceContext());
		m_pMonster->GetOrAddTransform()->SetPosition(Vec3{ 1.0f,1.0f,0.0f });
		{
			m_pMonster->GetOrAddTransform();
			shared_ptr<MeshRenderer> meshRenderer = make_shared<MeshRenderer>(m_pGraphics->GetDevice(), m_pGraphics->GetDeviceContext());
			m_pMonster->AddComponent(meshRenderer);

			shared_ptr<Material> material = RESOURCES->Get<Material>(L"Default");
			meshRenderer->SetMaterial(material);

			shared_ptr<Mesh> mesh = RESOURCES->Get<Mesh>(L"Rectangle");
			meshRenderer->SetMesh(mesh);
		}
		{
			shared_ptr<Animator> animator = make_shared<Animator>();
			m_pMonster->AddComponent(animator);
			shared_ptr<Animation> anim = GGame->GetResourceMGR()->Get<Animation>(L"SnakeAnim");
			animator->SetAnimation(anim);
		}
		scene->AddGameObject(m_pMonster);
	}

	return scene;
}
