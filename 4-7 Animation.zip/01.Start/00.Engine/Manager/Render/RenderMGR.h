#pragma once
#include "RenderHelper.h"

class RenderMGR
{
public:
	RenderMGR(ComPtr<ID3D11Device> device, ComPtr<ID3D11DeviceContext> deviceContext);
	~RenderMGR();

	void Init();
	void Update(shared_ptr<Graphics> graphics);

private:
	void PushCameraData();
	void PushTransformData();
	void PushAnimationData();

	void GatherRenderableObjects();
	void RenderObjects();

private:
	ComPtr<ID3D11Device> m_pDevice;
	ComPtr<ID3D11DeviceContext> m_pDeviceContext;
	shared_ptr<Pipeline> m_pPipeline;

private:
	//Camera
	CameraData m_cCameraData;
	shared_ptr<ConstantBuffer<CameraData>> m_pCameraBuffer;

	//SRT
	TransformData m_cTransformData;
	shared_ptr<ConstantBuffer<TransformData>> m_pTransformBuffer;

	//Animation
	AnimationData m_cAnimationData;
	shared_ptr<ConstantBuffer<AnimationData>> m_pAnimationBuffer;

	shared_ptr<Rasterizer> m_pRS;
	shared_ptr<BlendState> m_pBlend;
	shared_ptr<SamplerState> m_pSampler;

	vector<shared_ptr<GameObject>> m_vRenderObject;
};
