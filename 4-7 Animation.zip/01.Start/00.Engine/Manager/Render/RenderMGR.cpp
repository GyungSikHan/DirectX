#include "pch.h"
#include "Render/RenderMGR.h"
#include "../Render/RenderHelper.h"
#include "Pipeline.h"
#include "Camera/Camera.h"
#include "Game.h"
#include "SceneManager.h"
#include "Scene.h"
#include "Animation/Animator.h"
#include "Resource/Mesh.h"

RenderMGR::RenderMGR(ComPtr<ID3D11Device> device, ComPtr<ID3D11DeviceContext> deviceContext)
	:m_pDevice(device),m_pDeviceContext(deviceContext)
{
}

RenderMGR::~RenderMGR()
{
}

void RenderMGR::Init()
{
	m_pPipeline = make_shared<Pipeline>(m_pDeviceContext);

	//CreateCameraBuffer
	m_pCameraBuffer = make_shared<ConstantBuffer<CameraData>>(m_pDevice, m_pDeviceContext);
	m_pCameraBuffer->Create();
	//CreateConstantBuffer
	m_pTransformBuffer = make_shared<ConstantBuffer<TransformData>>(m_pDevice, m_pDeviceContext);
	m_pTransformBuffer->Create();
	//CreateAnimationBuffer
	m_pAnimationBuffer = make_shared<ConstantBuffer<AnimationData>>(m_pDevice, m_pDeviceContext);
	m_pAnimationBuffer->Create();

	//Rasterrize
	m_pRS = make_shared<Rasterizer>(m_pDevice);
	m_pRS->Create();

	//CreateBlendState
	m_pBlend = make_shared<BlendState>(m_pDevice);
	m_pBlend->Create();

	//CreateSamplerState
	m_pSampler = make_shared<SamplerState>(m_pDevice);
   	m_pSampler->Create();
}

void RenderMGR::Update(shared_ptr<Graphics> graphics)
{
	graphics->RenderBegin();

	PushCameraData();
	GatherRenderableObjects();
	RenderObjects();

	graphics->RenderEnd();
}

void RenderMGR::PushCameraData()
{
	m_cCameraData.View = Camera::m_mMatView;
	m_cCameraData.Projection = Camera::m_mProjection;

	m_pCameraBuffer->CopyData(m_cCameraData);
}

void RenderMGR::PushTransformData()
{
	//��ü���� Transform�� �ٸ����̹Ƿ� �׶� �˾Ƽ� ä���ָ� ��
	m_pTransformBuffer->CopyData(m_cTransformData);
}

void RenderMGR::PushAnimationData()
{
	m_pAnimationBuffer->CopyData(m_cAnimationData);
}

void RenderMGR::GatherRenderableObjects()
{
	m_vRenderObject.clear();

	const vector<shared_ptr<GameObject>>& gameObjects = SCENE->GetActiveScene()->GetGameObjects();
	for (const shared_ptr<GameObject>& gameObject : gameObjects)
	{
		shared_ptr<MeshRenderer> mesh = gameObject->GetMeshRenderer();
		if (mesh != nullptr)
			m_vRenderObject.push_back(gameObject);
	}
}

void RenderMGR::RenderObjects()
{
	for (const shared_ptr<GameObject>& gameObject :	m_vRenderObject)
	{
		shared_ptr<MeshRenderer> meshRenderer = gameObject->GetMeshRenderer();
		if (meshRenderer == nullptr)
			continue;
		shared_ptr<Transform> transform = gameObject->GetTransform();
		if(transform == nullptr)
			continue;

		//SRT
		m_cTransformData.World = transform->GetWorldMatrix();
		PushTransformData();

		//Animation
		shared_ptr<Animator> animator = gameObject->GetAnimator();
		if(animator != nullptr)
		{
			const Keyframe& keyframe = animator->GetCurrentKeyframe();
			m_cAnimationData.spriteOffset = keyframe.offset;
			m_cAnimationData.spriteSize = keyframe.size;
			m_cAnimationData.textureSize = animator->GetCurrentAnimation()->GetTextureSize();
			m_cAnimationData.useAnimation = 1.0f;
			PushAnimationData();
			m_pPipeline->ConstantBuffer(2, EVertexShader, m_pAnimationBuffer);
			m_pPipeline->SetTexture(0, EPixelShader, animator->GetCurrentAnimation()->GetTexture());
		}
		else
		{
			m_cAnimationData.spriteOffset = Vec2(0.0f,0.0f);
			m_cAnimationData.spriteSize = Vec2(0.0f, 0.0f);
			m_cAnimationData.textureSize = Vec2(0.0f, 0.0f);
			m_cAnimationData.useAnimation = 0.0f;
			PushAnimationData();
		
			m_pPipeline->ConstantBuffer(2, EVertexShader, m_pAnimationBuffer);
			m_pPipeline->SetTexture(0, EPixelShader, meshRenderer->GetTexture());
		}

		//IA - VS - RS - PS - OM
		PipelineInfo info;

		info.inputLayout = meshRenderer->GetInputLayout();
		info.vertexShader = meshRenderer->GetVertexShader();
		info.pixelShader = meshRenderer->GetPixelShader();
		info.rs = m_pRS;
		info.blend = m_pBlend;

		m_pPipeline->UpdatePipeline(info);

		m_pPipeline->SetVertexBuffer(meshRenderer->GetMesh()->GetVertexBuffer());
		m_pPipeline->SetIndexBuffer(meshRenderer->GetMesh()->GetIndexBuffer());

		m_pPipeline->ConstantBuffer(0, EVertexShader, m_pCameraBuffer);
		m_pPipeline->ConstantBuffer(1, EVertexShader, m_pTransformBuffer);

		//m_pPipeline->SetTexture(0, EPixelShader, meshRenderer->GetTexture());
		m_pPipeline->SetSamplerState(0, EPixelShader, m_pSampler);

		m_pPipeline->DrawIndexed(meshRenderer->GetMesh()->GetIndexBuffer()->GetCount(), 0, 0);
	}
}
