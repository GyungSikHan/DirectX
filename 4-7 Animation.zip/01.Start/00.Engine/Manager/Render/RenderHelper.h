#pragma once

struct TransformData
{
	Matrix World = Matrix::Identity;
};

struct CameraData
{
	Matrix View = Matrix::Identity;
	Matrix Projection = Matrix::Identity;
};

struct AnimationData
{
	Vec2 textureSize = Vec2::Zero;
	Vec2 spriteOffset = Vec2::Zero;
	Vec2 spriteSize = Vec2::Zero;
	float useAnimation;
	float padding;
};
