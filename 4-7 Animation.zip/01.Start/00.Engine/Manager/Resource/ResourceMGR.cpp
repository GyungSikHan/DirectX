#include "pch.h"
#include "Resource/ResourceMGR.h"

#include "Resource/Animation.h"
#include "Resource/Material.h"
#include "Resource/Texture.h"
#include "Resource/Mesh.h"
#include "Resource/Shader.h"

ResourceMGR::ResourceMGR(ComPtr<ID3D11Device> device)
	:m_pDevice(device), m_arResources()
{
}

void ResourceMGR::Init()
{
	CreateDefaultTexture();
	CreateDefaultMesh();
	CreateDefaultShader();
	CreateDefaultMaterial();
	CreateDefaultAnimation();
}

void ResourceMGR::CreateDefaultTexture()
{
	{
		shared_ptr<Texture> texture = make_shared<Texture>(m_pDevice);
		texture->SetName(L"Test");
		texture->Create(L"IMG_1018.HEIC");
		Add(texture->GetName(), texture);
	}
	{
		shared_ptr<Texture> texture = make_shared<Texture>(m_pDevice);
		texture->SetName(L"Snake");
		texture->Create(L"Snake.bmp");
		Add(texture->GetName(), texture);
	}
}

void ResourceMGR::CreateDefaultMesh()
{
	//Mesh
	shared_ptr<Mesh> mesh = make_shared<Mesh>(m_pDevice);
	mesh->SetName(L"Rectangle");
	mesh->CreateDefaultRectanble();
	Add(mesh->GetName(), mesh);
}

void ResourceMGR::CreateDefaultShader()
{
	//Create VS
	shared_ptr<VertexShader> vertexShader = make_shared<VertexShader>(m_pDevice);
	vertexShader->Create(L"Default.hlsl", "VS", "vs_5_0");

	//CreateInputLayout
	shared_ptr<InputLayout> inputLayout = make_shared<InputLayout>(m_pDevice);
	inputLayout->Create(VertexTextureData::descs, vertexShader->GetBlob());

	//CreatePS
	shared_ptr<PixelShader> pixelShader = make_shared<PixelShader>(m_pDevice);
	pixelShader->Create(L"Default.hlsl", "PS", "ps_5_0");

	shared_ptr<Shader> shader = make_shared<Shader>();
	shader->SetName(L"Default");
	shader->SetInputLayout(inputLayout);
	shader->SetVertexShader(vertexShader);
	shader->SetPixelShader(pixelShader);

	Add(shader->GetName(), shader);
}

void ResourceMGR::CreateDefaultMaterial()
{
	shared_ptr<Material> material = make_shared<Material>();
	material->SetName(L"Default");
	material->SetShader(Get<Shader>(L"Default"));
	material->SetTexture(Get<Texture>(L"Test"));
	Add(material->GetName(), material);
}

void ResourceMGR::CreateDefaultAnimation()
{
	shared_ptr<Animation> animation = make_shared<Animation>();
	animation->SetName(L"SnakeAnim");
	animation->SetTexture(Get<Texture>(L"Snake"));
	animation->SetLoop(true);

	animation->AddKeyframe(Keyframe{ Vec2{0.0f,0.0f}, Vec2{100.0f,100.0f}, 0.1f });
	animation->AddKeyframe(Keyframe{ Vec2{100.0f,0.0f}, Vec2{100.0f,100.0f}, 0.1f });
	animation->AddKeyframe(Keyframe{ Vec2{200.0f,0.0f}, Vec2{100.0f,100.0f}, 0.1f });
	animation->AddKeyframe(Keyframe{ Vec2{300.0f,0.0f}, Vec2{100.0f,100.0f}, 0.1f });

	Add(animation->GetName(), animation);
}
