#include "pch.h"
#include "GameObject.h"
#include "Camera/Camera.h"
#include "MonoBehaviour.h"
#include "Transform.h"

GameObject::GameObject(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext)
	:device(Device)
{
}

GameObject::~GameObject()
{
}

void GameObject::Awake()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->Awake();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->Awake();
}

void GameObject::Start()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->Start();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->Start();
}

void GameObject::Update()
{
	for (shared_ptr<Component>& component : m_aComponents)
	{
		if (component != nullptr)
			component->Update();
	}

	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
	{
		script->Update();
	}
}

void GameObject::LateUpdate()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->LateUpdate();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->LateUpdate();
}

void GameObject::FixedUpdate()
{
	for (shared_ptr<Component>& component : m_aComponents)
		if (component != nullptr)
			component->FixedUpdate();
	for (shared_ptr<MonoBehaviour>& script : m_vScripts)
		script->FixedUpdate();
}

shared_ptr<Component> GameObject::GetFixedComponent(ComponentType type)
{
	uint8 index = static_cast<uint8>(type);
	assert(index < FIXED_COMPONENT_COUNT);
	return m_aComponents[index];
}

shared_ptr<Transform> GameObject::GetTransform()
{
	shared_ptr<Component> component = GetFixedComponent(ComponentType::Transform);
	return static_pointer_cast<Transform>(component);
}

shared_ptr<Camera> GameObject::GetCamera()
{
	shared_ptr<Component> component = GetFixedComponent(ComponentType::Camera);
	return static_pointer_cast<Camera>(component);
}

shared_ptr<MeshRenderer> GameObject::GetMeshRenderer()
{
	shared_ptr<Component> component = GetFixedComponent(ComponentType::MeshRenderer);
	return static_pointer_cast<MeshRenderer>(component);
}

shared_ptr<Animator> GameObject::GetAnimator()
{
	shared_ptr<Component> component = GetFixedComponent(ComponentType::Animator);
	return static_pointer_cast<Animator>(component);
}

shared_ptr<Transform> GameObject::GetOrAddTransform()
{
	if(GetTransform() == nullptr)
	{
		shared_ptr<Transform>transform = make_shared<Transform>();
		AddComponent(transform);
	}

	return GetTransform();
}

void GameObject::AddComponent(shared_ptr<Component> component)
{
	component->SetGameObject(shared_from_this());
	uint8 index = static_cast<uint8>(component->GetType());
	if (index < FIXED_COMPONENT_COUNT)
		m_aComponents[index] = component;
	else
		m_vScripts.push_back(dynamic_pointer_cast<MonoBehaviour>(component));
}
