#pragma once

enum ShaderBaseScope
{
	ENone = 0,
	EVertexShader = (1 << 0),
	EPixelShader = (1 << 1),
	EBoth = EVertexShader | EPixelShader
};

class ShaderBase
{
public:
	ShaderBase(ComPtr<ID3D11Device> Device);
	virtual ~ShaderBase();//��ӹ��� ����

	virtual void Create(const wstring& Path, const string& Name, const string& version);

	ComPtr<ID3DBlob> GetBlob() { return blob; }

protected:
	void LoadShaderFormFile(const wstring& Path, const string& Name, const string& version);

protected:
	wstring path;
	string name;
	ComPtr<ID3D11Device> device;
	ComPtr<ID3DBlob> blob;
};


