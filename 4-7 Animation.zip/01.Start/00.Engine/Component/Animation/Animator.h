#pragma once
#include "Component.h"
#include "Resource/Animation.h"

class Animator : public Component
{
	using Super = Component;
public:
	Animator();
	virtual ~Animator();

	void Init();
	void Update();

	shared_ptr<Animation> GetCurrentAnimation();
	const Keyframe& GetCurrentKeyframe();
	void SetAnimation(shared_ptr<Animation> animation);

private:
	float m_fSumTime = 0.0f;
	int32 m_nCurrentKeyframeIndex = 0;
	shared_ptr<Animation> m_pCurrentAnimation;
};
