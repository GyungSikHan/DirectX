#include "pch.h"
#include "Animation/Animator.h"
#include "Game.h"
#include "Time/TimeManager.h"

Animator::Animator()
	:Super(ComponentType::Animator)
{
}

Animator::~Animator()
{
}

void Animator::Init()
{
}

void Animator::Update()
{
	
	shared_ptr<Animation> animation = GetCurrentAnimation();
	if(animation == nullptr)
		return;

	const Keyframe& keyframe = animation->GetKeyframe(m_nCurrentKeyframeIndex);
	float deltaTime = TIME->GetDeltaTime();
	m_fSumTime += deltaTime;

	if(m_fSumTime >= keyframe.time)
	{
		m_nCurrentKeyframeIndex++;
		int32 totalCount = animation->GetKeyframeCount();

		if(m_nCurrentKeyframeIndex >= totalCount)
		{
			if (animation->IsLoop() == true)
				m_nCurrentKeyframeIndex = 0;
			else
				m_nCurrentKeyframeIndex = totalCount - 1;
		}

		m_fSumTime = 0.0f;
	}

}

shared_ptr<Animation> Animator::GetCurrentAnimation()
{
	return m_pCurrentAnimation;
}

const Keyframe& Animator::GetCurrentKeyframe()
{
	return m_pCurrentAnimation->GetKeyframe(m_nCurrentKeyframeIndex);
}

void Animator::SetAnimation(shared_ptr<Animation> animation)
{
	m_pCurrentAnimation = animation;
}
