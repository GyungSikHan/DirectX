#include "pch.h"
#include "Component.h"

#include "GameObject.h"

Component::Component(ComponentType type):
m_eType(type)
{
}

Component::~Component()
{
}

shared_ptr<GameObject> Component::GetGameObject()
{
	return owner.lock();
}

shared_ptr<Transform> Component::GetTransform()
{
	return owner.lock().get()->GetTransform();
}
