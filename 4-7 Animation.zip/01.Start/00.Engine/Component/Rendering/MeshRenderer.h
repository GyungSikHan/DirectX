#pragma once
#include "Resource/Material.h"
#include "Resource/Shader.h"

class Mesh;

class MeshRenderer : public Component
{
	using Super = Component;

public:
	MeshRenderer(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext);
	~MeshRenderer();

	virtual void Update() override;
	
public:
	void SetMesh(shared_ptr<Mesh> mesh);
	void SetMaterial(shared_ptr<Material> material);
	void SetShader(shared_ptr<Shader> shader);
	void SetTexture(shared_ptr<Texture> texture);

	shared_ptr<Mesh> GetMesh() { return m_pMesh; }
	shared_ptr<Material> GetMaterial() { return m_pMaterial; }
	shared_ptr<VertexShader> GetVertexShader() { return m_pMaterial->GetShader()->GetVertexShader(); }
	shared_ptr<PixelShader> GetPixelShader() { return m_pMaterial->GetShader()->GetPixelShader(); }
	shared_ptr<InputLayout> GetInputLayout() { return m_pMaterial->GetShader()->GetInputLayout(); }
	shared_ptr<Texture> GetTexture() { return m_pMaterial->GetTexture(); }

private:
	ComPtr<ID3D11Device> m_pDevice;

	//Mesh
	shared_ptr<Mesh> m_pMesh;
	//Material
	shared_ptr<Material> m_pMaterial;
};

