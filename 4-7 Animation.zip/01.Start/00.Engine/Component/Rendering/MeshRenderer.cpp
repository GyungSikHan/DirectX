#include "pch.h"
#include "MeshRenderer.h"
#include "Game.h"
#include "Camera/Camera.h"
#include "Resource/Mesh.h"
#include "Resource/Material.h"

MeshRenderer::MeshRenderer(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext)
: Super (ComponentType::MeshRenderer), m_pDevice(Device)
{
}

MeshRenderer::~MeshRenderer()
{
}

void MeshRenderer::Update()
{
	Component::Update();
}

void MeshRenderer::SetMesh(shared_ptr<Mesh> mesh)
{
	m_pMesh = mesh;
}

void MeshRenderer::SetMaterial(shared_ptr<Material> material)
{
	m_pMaterial = material;
}

void MeshRenderer::SetShader(shared_ptr<Shader> shader)
{
	m_pMaterial->SetShader(shader);
}

void MeshRenderer::SetTexture(shared_ptr<Texture> texture)
{
	m_pMaterial->SetTexture(texture);
}
