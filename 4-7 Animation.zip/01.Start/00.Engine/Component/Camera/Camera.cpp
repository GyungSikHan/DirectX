#include "pch.h"
#include "Camera.h"

Matrix Camera::m_mMatView = Matrix::Identity;
Matrix Camera::m_mProjection = Matrix::Identity;

Camera::Camera() : Component(ComponentType::Camera)
{
}

 Camera::~Camera()
{
}

 void Camera::Update()
{
	Component::Update();
	UpdateMatrix();
}

void Camera::SetProjectionType(ProjectionType type)
{
	m_eType = type;
}


void Camera::UpdateMatrix()
{
	Vec3 eye = GetTransform()->GetPosition();
	Vec3 focus = eye + GetTransform()->GetLook();
	Vec3 upDirection = GetTransform()->GetUp();//������ �� ����ص� �ȴ�
	m_mMatView = ::XMMatrixLookAtLH(eye, focus, upDirection);
	//m_mMatView = GetTransform()->GetWorldMatrix().Invert();//���� ���� ����

	if (m_eType == ProjectionType::Perspective)
		m_mProjection = ::XMMatrixPerspectiveFovLH(XM_PI / 4.0f, 800.0f / 600.0f, 1.0f, 100.0f);
	else
		m_mProjection = XMMatrixOrthographicLH(8.0f, 6.0f, 0.0f, 1.0f);
}
