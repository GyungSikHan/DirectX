#include "pch.h"
#include "Texture.h"

Texture::Texture(ComPtr<ID3D11Device> Device)
	:device(Device), Super(ResourceType::Texture)
{
}

Texture::~Texture()
{
}

void Texture::Create(const wstring& path)
{
	DirectX::TexMetadata md{};
	DirectX::ScratchImage img{};

	HRESULT hr = ::LoadFromWICFile(path.c_str(), WIC_FLAGS_NONE, &md, img);
	CHECK(hr);
	hr = ::CreateShaderResourceView(device.Get(), img.GetImages(), img.GetImageCount(), md, srv.GetAddressOf());
	CHECK(hr);

	size.x = md.width;
	size.y = md.height;
}
