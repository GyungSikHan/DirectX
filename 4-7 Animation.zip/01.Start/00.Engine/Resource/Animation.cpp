#include "pch.h"
#include "Resource/Animation.h"

Animation::Animation() : Super(ResourceType::Animation)
{
}

Animation::~Animation()
{
}

void Animation::Load(const wstring& path)
{
	ResourceBase::Load(path);
}

void Animation::Save(const wstring& path)
{
	ResourceBase::Save(path);
}

void Animation::SetLoop(bool loop)
{
	bLoop = loop;
}

void Animation::SetTexture(shared_ptr<Texture> texture)
{
	m_pTexture = texture;
}

Vec2 Animation::GetTextureSize()
{
	return m_pTexture->GetSize();
}

const Keyframe& Animation::GetKeyframe(int32 index)
{
	return m_vKeyframes[index];
}

int32 Animation::GetKeyframeCount()
{
	return static_cast<int32>(m_vKeyframes.size());
}

void Animation::AddKeyframe(const Keyframe& keyframe)
{
	m_vKeyframes.push_back(keyframe);
}