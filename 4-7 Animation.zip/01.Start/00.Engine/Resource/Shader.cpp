#include "pch.h"
#include "Resource/Shader.h"

Shader::Shader() : Super(ResourceType::Shader)
{
}

Shader::~Shader()
{
}

void Shader::SetInputLayout(shared_ptr<InputLayout> input)
{
	m_pInputLayout = input;
}

void Shader::SetVertexShader(shared_ptr<VertexShader> vertex)
{
	m_pVertexShader = vertex;
}

void Shader::SetPixelShader(shared_ptr<PixelShader> pixel)
{
	m_pPixelShader = pixel;
}
