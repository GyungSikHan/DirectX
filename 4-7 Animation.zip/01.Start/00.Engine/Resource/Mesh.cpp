#include "pch.h"
#include "Resource/Mesh.h"

Mesh::Mesh(ComPtr<ID3D11Device> device)
	: Super(ResourceType::Mesh), m_pDevice(device)
{
}

Mesh::~Mesh()
{
}

void Mesh::CreateDefaultRectanble()
{
	//Create Geometry
	m_pGeometry = make_shared<Geometry<VertexTextureData>>();
	GeometryHelper::CreateRectangle(m_pGeometry);

	//VertexBuffer
	m_pVertexBuffer = make_shared<VertexBuffer>(m_pDevice);
	m_pVertexBuffer->Create<VertexTextureData>(m_pGeometry->GetVertices());

	//IndexBuffer
	m_pIndexBuffer = make_shared<IndexBuffer>(m_pDevice);
	m_pIndexBuffer->Create(m_pGeometry->GetIndices());
}
