#pragma once
#include "Resource/ResourceBase.h"

struct Keyframe
{
	Vec2 offset = Vec2{ 0.0f,0.0f };
	Vec2 size = Vec2{ 0.0f,0.0f };
	float time = 0.0f ;
};

class Animation : public ResourceBase
{
	using Super = ResourceBase;
public:
	Animation();
	virtual ~Animation();

	virtual void Load(const wstring& path) override;
	virtual void Save(const wstring& path) override;

	void SetLoop(bool loop);
	bool IsLoop() { return bLoop; }

	void SetTexture(shared_ptr<Texture> texture);
	shared_ptr<Texture> GetTexture() { return m_pTexture; }

	Vec2 GetTextureSize();

	const Keyframe& GetKeyframe(int32 index);
	int32 GetKeyframeCount();
	void AddKeyframe(const Keyframe& keyframe);

private:
	bool bLoop = false;
	shared_ptr<Texture> m_pTexture;
	vector<Keyframe> m_vKeyframes;
};


