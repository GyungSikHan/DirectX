#pragma once
class Graphics
{
public:
	Graphics(HWND hWnd);
	~Graphics();

	void RenderBegin();
	void RenderEnd();

	ComPtr<ID3D11Device> GetDevice() { return device; }
	ComPtr<ID3D11DeviceContext> GetDeviceContext() { return deviceContext; }

private:
	void CreateDeviceAndSpwaChain();
	void CreateRenderTargetView();
	void SetViewport();

private:
	HWND hwnd;
	uint32 width = 0;
	uint32 height = 0;

private:
	//Device & SwapChain
	ComPtr<ID3D11Device> device{};
	ComPtr<ID3D11DeviceContext> deviceContext{};
	ComPtr<IDXGISwapChain> swapChain{};

	//RTV
	ComPtr<ID3D11RenderTargetView> renderTargetView;

	//Misc
	D3D11_VIEWPORT viewport{};
	float clearColor[4] = { 1.0f,1.0f ,1.0f ,1.0f };
};

