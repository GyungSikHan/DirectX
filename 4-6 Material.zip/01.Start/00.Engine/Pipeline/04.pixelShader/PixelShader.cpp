#include "pch.h"
#include "PixelShader.h"

PixelShader::PixelShader(ComPtr<ID3D11Device> Device)
	:Super(Device)
{
}

PixelShader::~PixelShader()
{
}

void PixelShader::Create(const wstring& Path, const string& Name, const string& version)
{
	ShaderBase::Create(Path, Name, version);

	LoadShaderFormFile(Path, Name, version);
	HRESULT hr = device->CreatePixelShader(blob->GetBufferPointer(),
		blob->GetBufferSize(), nullptr, pixelShader.GetAddressOf());
	CHECK(hr);
}