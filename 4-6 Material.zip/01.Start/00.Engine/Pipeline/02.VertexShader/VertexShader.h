#pragma once
class VertexShader : public ShaderBase
{
	using Super = ShaderBase;
public:
	VertexShader(ComPtr<ID3D11Device> Device);
	~VertexShader();

	ComPtr<ID3D11VertexShader> GetComPtr() { return vertexShaderBase; }

	void Create(const wstring& Path, const string& Name, const string& version) override;

protected:
	ComPtr<ID3D11VertexShader> vertexShaderBase{};
};
