#include "pch.h"
#include "Resource/Material.h"

Material::Material() : Super(ResourceType::Material)
{
}

Material::~Material()
{
}

void Material::SetShader(shared_ptr<Shader> shader)
{
	m_pShader = shader;
}

void Material::SetTexture(shared_ptr<Texture> texture)
{
	m_pTexture = texture;
}
