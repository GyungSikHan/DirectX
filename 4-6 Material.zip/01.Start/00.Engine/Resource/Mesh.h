#pragma once
#include "Resource/ResourceBase.h"

class Mesh : public ResourceBase
{
	using Super = ResourceBase;
public:
	Mesh(ComPtr<ID3D11Device> device);
	virtual ~Mesh();

	void CreateDefaultRectanble();

	shared_ptr<VertexBuffer> GetVertexBuffer() { return m_pVertexBuffer; }
	shared_ptr<IndexBuffer> GetIndexBuffer() { return m_pIndexBuffer; }

private:
	ComPtr<ID3D11Device> m_pDevice;
	//Mesh
	shared_ptr<Geometry<VertexTextureData>> m_pGeometry;
	shared_ptr<VertexBuffer> m_pVertexBuffer;
	shared_ptr<IndexBuffer> m_pIndexBuffer;
};