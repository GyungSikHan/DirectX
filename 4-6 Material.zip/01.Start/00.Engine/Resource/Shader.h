#pragma once
#include "Resource/ResourceBase.h"

class Shader : public ResourceBase
{
	using Super = ResourceBase;
public:
	Shader();
	virtual ~Shader();

	void SetInputLayout(shared_ptr<InputLayout> input);
	void SetVertexShader(shared_ptr<VertexShader> vertex);
	void SetPixelShader(shared_ptr<PixelShader> pixel);

	shared_ptr<InputLayout> GetInputLayout() { return m_pInputLayout; }
	shared_ptr<VertexShader> GetVertexShader() { return m_pVertexShader; }
	shared_ptr<PixelShader> GetPixelShader() { return m_pPixelShader; }

private:
	//Material
	shared_ptr<InputLayout> m_pInputLayout; // Vertex shader�� �Ѱ��� �� � ������� �������ֹǷ� ���� ���������Ѵ�
	shared_ptr<VertexShader> m_pVertexShader;
	shared_ptr<PixelShader> m_pPixelShader;
};