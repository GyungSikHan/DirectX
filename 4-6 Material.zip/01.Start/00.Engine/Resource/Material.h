#pragma once
#include "Resource/ResourceBase.h"

class Shader;
class Texture;

class Material : public ResourceBase
{
	using Super = ResourceBase;
public:
	Material();
	virtual ~Material();

public:
	void SetShader(shared_ptr<Shader> shader);
	void SetTexture(shared_ptr<Texture> texture);

	shared_ptr<Shader> GetShader() { return m_pShader; }
	shared_ptr<Texture> GetTexture() { return m_pTexture; }

private:
	shared_ptr<Shader> m_pShader;
	//���̴��� �ѱ�� �°� ���ڵ�
	shared_ptr<Texture> m_pTexture;
};