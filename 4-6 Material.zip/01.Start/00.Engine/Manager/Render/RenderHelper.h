#pragma once

struct TransformData
{
	Matrix World = Matrix::Identity;
};

struct CameraData
{
	Matrix View = Matrix::Identity;
	Matrix Projection = Matrix::Identity;
};