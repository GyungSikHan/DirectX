#include "pch.h"
#include "VertexBuffer.h"

VertexBuffer::VertexBuffer(ComPtr<ID3D11Device> Device)
	:device(Device)
{
}

VertexBuffer::~VertexBuffer()
{
}
