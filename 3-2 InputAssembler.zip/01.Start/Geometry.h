#pragma once

template<typename T>
class Geometry
{
public:
	Geometry(){};
	~Geometry(){};

	uint32 GetVertexCount() { return static_cast<uint32>(vertices.size()); }
	//���Ϳ� �� �ϳ� �߰�
	void AddVertex(const T& vertex) { vertices.push_back(vertex); }

	void AddVertices(const vector<T>& Vertices) { vertices.insert(vertices.end(), vertices.begin(), vertices.end()); }
	//���͸� ��ä�� �߰�
	void SetVertices(const vector<T>& Vertices) { vertices = Vertices; }
private:
	vector<T> vertices;
	vector<uint32> indices;
};