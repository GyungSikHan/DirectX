#pragma once
#include "pch.h"

class Game
{
public:
	Game();
	~Game();

public:
	void Init(HWND hWnd);
	void Update();
	void Render();

private:
	void CreateGeometry();
	void CreateInputLayout();

	void CreateVS();

	void CreateRasterizerState();
	void CreateSamplerState();
	void CreateBlendState();

	void CreatePS();
	//SRV = Shader Resource View
	void CreateSRV();

	void CreateConstantBuffer();

	void LoadShaderFromFile(const wstring& path, const string& name, const string& version, ComPtr<ID3DBlob>& blob);

private:
	HWND hwnd;
	shared_ptr<Graphics> graphics;

private:
	//Geometry
	vector<Vertex> vertices;
	vector<uint32> indices;
	shared_ptr<VertexBuffer> vertexBuffer;
	shared_ptr<IndexBuffer> indexBuffer;

	shared_ptr<InputLayout> inputLayout;

	//VS
	ComPtr<ID3D11VertexShader> vertexShader{};
	ComPtr<ID3DBlob> vsBlob{};

	//RS
	ComPtr<ID3D11RasterizerState> rs;

	//PS
	ComPtr<ID3D11PixelShader> pixeShader{};
	ComPtr<ID3DBlob> psBlob{};

	ComPtr<ID3D11SamplerState> sampler;

	ComPtr<ID3D11BlendState> blend;

	//SRV
	ComPtr<ID3D11ShaderResourceView> srv;

private:
	//SRT
	TransformData transformData;
	ComPtr<ID3D11Buffer> constantBuffer;

	Vec3 localPosition = {};
	Vec3 localRotation = {};
	Vec3 localScale = {1.0f,1.0f,1.0f};
};

