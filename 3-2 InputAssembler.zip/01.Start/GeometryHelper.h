#pragma once
class GeometryHelper
{
};

