#include "pch.h"
#include "Game.h"

Game::Game()
{
}

Game::~Game()
{
}

void Game::Init(HWND hWnd)
{
	hwnd = hWnd;
	
	graphics = make_shared<Graphics>(hwnd);
	vertexBuffer = make_shared<VertexBuffer>(graphics->GetDevice());
	indexBuffer = make_shared<IndexBuffer>(graphics->GetDevice());
	inputLayout = make_shared<InputLayout>(graphics->GetDevice());

	CreateGeometry();
	CreateVS();
	CreateInputLayout();

	CreateRasterizerState();
	CreateSamplerState();

	CreatePS();
	CreateSRV();

	CreateBlendState();

	CreateConstantBuffer();
}

void Game::Update()
{
	//Scale Rotation Translation

	localPosition.x += 0.001f;

	Matrix scale = Matrix::CreateScale(localScale);
	Matrix rotation = Matrix::CreateRotationX(localRotation.x);
	rotation *= Matrix::CreateRotationY(localRotation.y);
	rotation *= Matrix::CreateRotationZ(localRotation.z);
	Matrix translation = Matrix::CreateTranslation(localPosition);

	Matrix world = scale * rotation * translation;
	transformData.World = world;

	D3D11_MAPPED_SUBRESOURCE sub{};
	ZeroMemory(&sub, sizeof(sub));

	graphics->GetDeviceContext()->Map(constantBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &sub);
	::memcpy(sub.pData, &transformData, sizeof(transformData));
	graphics->GetDeviceContext()->Unmap(constantBuffer.Get(), 0);
}

void Game::Render()
{
	graphics->RenderBegin();

	//IA - VS - RS - PS - OM
	{
		uint32 stride = sizeof(Vertex);
		uint32 offset{};
		auto deviceContext = graphics->GetDeviceContext();
		//IA
		deviceContext->IASetVertexBuffers(0, 1, vertexBuffer->GetComPtr().GetAddressOf(), &stride, &offset);
		deviceContext->IASetIndexBuffer(indexBuffer->GetComPtr().Get(), DXGI_FORMAT_R32_UINT, 0);
		deviceContext->IASetInputLayout(inputLayout->GetComptr().Get());
		deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

		//VS
		deviceContext->VSSetShader(vertexShader.Get(), nullptr, 0);
		deviceContext->VSSetConstantBuffers(0, 1, constantBuffer.GetAddressOf());

		//RS
		deviceContext->RSSetState(rs.Get());

		//PS
		deviceContext->PSSetShader(pixeShader.Get(), nullptr, 0);
		deviceContext->PSSetShaderResources(0, 1, srv.GetAddressOf());
		deviceContext->PSSetSamplers(0, 1, sampler.GetAddressOf());
		
		//OM
		deviceContext->OMSetBlendState(blend.Get(), nullptr,  0xFFFFFFFF);

		deviceContext->DrawIndexed((UINT)indices.size(), 0, 0);
	}
	
	graphics->RenderEnd();
}

void Game::CreateGeometry()
{
	//VertexData
	{
		vertices.resize(4);

		vertices[0].position = Vec3(-.5f, -.5f, 0.0f);
		vertices[0].uv = Vec2(0.0f,1.0f);
		vertices[1].position = Vec3(-.5f, .5f, 0.0f);
		vertices[1].uv = Vec2(0.0f,0.0f);
		vertices[2].position = Vec3(.5f, -.5f, 0.0f);
		vertices[2].uv = Vec2(1.0f,1.0f);
		vertices[3].position = Vec3(.5f, .5f, 0.0f);
		vertices[3].uv = Vec2(1.0f,0.f);
	}

	//VertexBuffer
	{
		vertexBuffer->Create<Vertex>(vertices);
	}

	//index
	{
		indices = { 0,1,2,2,1,3 };
	}

	//IndexBuffer
	{
		indexBuffer->Create(indices);
	}
}

void Game::CreateInputLayout()
{
	vector<D3D11_INPUT_ELEMENT_DESC>layout = {
		{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT,
			0,0, D3D11_INPUT_PER_VERTEX_DATA},
		{"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,
			0,12, D3D11_INPUT_PER_VERTEX_DATA}
	};

	inputLayout->Create(layout, vsBlob);
}

void Game::CreateVS()
{
	LoadShaderFromFile(L"Default.hlsl", "VS", "vs_5_0", vsBlob);

	HRESULT hr = graphics->GetDevice()->CreateVertexShader(vsBlob->GetBufferPointer(),
		vsBlob->GetBufferSize(), nullptr, vertexShader.GetAddressOf());
	CHECK(hr);
}

void Game::CreateRasterizerState()
{
	D3D11_RASTERIZER_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.FillMode = D3D11_FILL_SOLID;
	desc.CullMode = D3D11_CULL_BACK;

	desc.FrontCounterClockwise = false;
	
	HRESULT hr = graphics->GetDevice()->CreateRasterizerState(&desc, rs.GetAddressOf());
	CHECK(hr);
}

void Game::CreateSamplerState()
{
	CD3D11_SAMPLER_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.AddressU = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.BorderColor[0] = 1;
	desc.BorderColor[1] = 0;
	desc.BorderColor[2] = 0;
	desc.BorderColor[3] = 1;
	desc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	desc.MaxAnisotropy = 16;
	desc.MaxLOD = FLT_MAX;
	desc.MinLOD = FLT_MAX;
	desc.MipLODBias = 0.0f;

	graphics->GetDevice()->CreateSamplerState(&desc, sampler.GetAddressOf());
}

void Game::CreateBlendState()
{
	D3D11_BLEND_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.AlphaToCoverageEnable = false;
	desc.IndependentBlendEnable = false;

	desc.RenderTarget[0].BlendEnable = true;
	desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
	desc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
	desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
	desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
	desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
	desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

	HRESULT hr = graphics->GetDevice()->CreateBlendState(&desc, blend.GetAddressOf());
	CHECK(hr);
}

void Game::CreatePS()
{
	LoadShaderFromFile(L"Default.hlsl", "PS", "ps_5_0", psBlob);
	HRESULT hr = graphics->GetDevice()->CreatePixelShader(psBlob->GetBufferPointer(),
		psBlob->GetBufferSize(), nullptr, pixeShader.GetAddressOf());
	CHECK(hr);
}

void Game::CreateSRV()
{
	DirectX::TexMetadata md{};
	DirectX::ScratchImage img{};

	HRESULT hr = ::LoadFromWICFile(L"IMG_0424.png", WIC_FLAGS_NONE, &md, img);
	CHECK(hr);
	hr = ::CreateShaderResourceView(graphics->GetDevice().Get(), img.GetImages(), img.GetImageCount(), md, srv.GetAddressOf());
	CHECK(hr);
}

void Game::CreateConstantBuffer()
{
	D3D11_BUFFER_DESC desc{};
	ZeroMemory(&desc, sizeof(desc));
	desc.Usage = D3D11_USAGE_DYNAMIC;
	desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	desc.ByteWidth = sizeof(TransformData);

	desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

	HRESULT hr = graphics->GetDevice()->CreateBuffer(&desc, nullptr, constantBuffer.GetAddressOf());
	CHECK(hr);
}

void Game::LoadShaderFromFile(const wstring& path, const string& name, const string& version, ComPtr<ID3DBlob>& blob)
{
	const uint32 compileFlag = D3DCOMPILE_DEBUG | D3DCOMPILE_SKIP_OPTIMIZATION;

	HRESULT hr =::D3DCompileFromFile(
		path.c_str(),
		nullptr,
		D3D_COMPILE_STANDARD_FILE_INCLUDE,
		name.c_str(),
		version.c_str(),
		compileFlag, 0,
		blob.GetAddressOf(),
		nullptr);

	CHECK(hr);
}
