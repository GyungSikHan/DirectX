#pragma once

class VertexBuffer
{
public:
	VertexBuffer(ComPtr<ID3D11Device> Device);
	~VertexBuffer();

	ComPtr<ID3D11Buffer> GetComPtr() { return vertexBuffer; }
	uint32 GetStride() { return stride; }
	uint32 GetOffset() { return offset; }
	uint32 GetCount() { return count; }

	template<typename T>
	void Create(const vector<Vertex>& vertices)
	{
		stride = sizeof(T);
		count = static_cast<uint32>(vertices.size());

		D3D11_BUFFER_DESC desc;
		ZeroMemory(&desc, sizeof(desc));
		desc.Usage = D3D11_USAGE_IMMUTABLE;
		desc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		desc.ByteWidth = (uint32)(stride*count);

		D3D11_SUBRESOURCE_DATA data;
		ZeroMemory(&data, sizeof(data));
		data.pSysMem = vertices.data();

		HRESULT hr = device->CreateBuffer(&desc, &data, vertexBuffer.GetAddressOf());
		CHECK(hr);
	}

private:
	ComPtr<ID3D11Device> device;
	ComPtr<ID3D11Buffer> vertexBuffer;

	uint32 stride{};
	uint32 offset{};
	uint32 count{};
};

