#include "pch.h"
#include "GameObject.h"

GameObject::GameObject(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext)
	:device(Device)
{
	//Create Geometry
	geometry = make_shared<Geometry<VertexTextureData>>();
	GeometryHelper::CreateRectangle(geometry);
	
	//VertexBuffer
	vertexBuffer = make_shared<VertexBuffer>(device);
	vertexBuffer->Create<VertexTextureData>(geometry->GetVertices());
	
	//IndexBuffer
	indexBuffer = make_shared<IndexBuffer>(device);
	indexBuffer->Create(geometry->GetIndices());

	//Create VS
	vertexShader = make_shared<VertexShader>(device);
	vertexShader->Create(L"Default.hlsl", "VS", "vs_5_0");

	//CreateInputLayout
	inputLayout = make_shared<InputLayout>(device);
	inputLayout->Create(VertexTextureData::descs, vertexShader->GetBlob());

	//CreatePS
	pixelShader = make_shared<PixelShader>(device);
	pixelShader->Create(L"Default.hlsl", "PS", "ps_5_0");

	//Rasterrize
	rs = make_shared<Rasterizer>(device);
	rs->Create();

	//CreateBlendState
	blend = make_shared<BlendState>(device);
	blend->Create();

	//CreateConstantBuffer
	constantBuffer = make_shared<ConstantBuffer<TransformData>>(device, DeviceContext);
	constantBuffer->Create();
	//CreateSRV
	srv = make_shared<Texture>(device);
	srv->Create(L"IMG_0424.png");
	//CreateSamplerState
	sampler = make_shared<SamplerState>(device);
	sampler->Create();

	parent->AddChild(transform);
	transform->SetParent(parent);
}

GameObject::~GameObject()
{
}

void GameObject::Update()
{
	//Vec3 pos = transform->GetPosition();
	//pos.x += 0.001f;
	//transform->SetPosition(pos);

	//Vec3 pos = parent->GetPosition();
	//pos.x += 0.001f;
	//parent->SetPosition(pos);
	Vec3 rot = parent->GetRotation();
	rot.y += 0.001f;
	parent->SetRotation(rot);

	transformData.World = transform->GetWorldMatrix();

	constantBuffer->CopyData(transformData);
}

void GameObject::Rneder(shared_ptr<Pipeline> Pipeline)
{
	//IA - VS - RS - PS - OM

	PipelineInfo info;

	info.inputLayout = inputLayout;
	info.vertexShader = vertexShader;
	info.pixelShader = pixelShader;
	info.rs = rs;
	info.blend = blend;

	Pipeline->UpdatePipeline(info);

	Pipeline->SetVertexBuffer(vertexBuffer);
	Pipeline->SetIndexBuffer(indexBuffer);
	Pipeline->ConstantBuffer(0, EVertexShader, constantBuffer);
	Pipeline->SetTexture(0, EPixelShader, srv);
	Pipeline->SetSamplerState(0, EPixelShader, sampler);
	
	Pipeline->DrawIndexed(geometry->GetIndexCount(), 0, 0);
}
