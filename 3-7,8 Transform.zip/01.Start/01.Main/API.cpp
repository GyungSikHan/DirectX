#include "pch.h"
#include "API.h"
#include "Resource.h"

shared_ptr<C_WINAPI> C_WINAPI::m_pApi = nullptr;

void C_WINAPI::Init(HINSTANCE hInstance)
{
	InitMsgFunc();
	m_hInstance = hInstance;

    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = m_hInstance;
    wcex.hIcon = LoadIcon(m_hInstance, MAKEINTRESOURCE(IDI_MY01START));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = nullptr;//�ɼǸ޴�â�� �ʿ������ null�� ����
    wcex.lpszClassName = L"GameCoding";//class name����, �� Ű�� �̿��Ͽ� InitInstance �Լ����� â�� ����
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    RegisterClassExW(&wcex);

    RECT windowRect = { 0,0, GWinSizeX,GWinSizeY };
    ::AdjustWindowRect(&windowRect, WS_OVERLAPPEDWINDOW, false);
    HWND hWnd = CreateWindowW(L"GameCoding", L"Client", WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, windowRect.right - windowRect.left, windowRect.bottom - windowRect.top, nullptr, nullptr, hInstance, nullptr);

    if (!hWnd)
        return;

    ShowWindow(hWnd, SW_SHOWDEFAULT);
    UpdateWindow(hWnd);

    game.Init(hWnd);
}

void C_WINAPI::UpdateMsg()
{
    MSG msg{};

    while (msg.message != WM_QUIT)//���� �ڵ�� �޸� ���ӿ��� â�� ������ �ʴٸ� ���ѷ����� â�� ���� ����
    {
        if (::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else//���ӿ� �ʿ��� �޼��� ����
        {
            game.Update();
            game.Render();
        }
    }
}

void C_WINAPI::InitMsgFunc()
{
    m_arMsgFuc[WM_PAINT] = &C_WINAPI::OnPaint;
    m_arMsgFuc[WM_DESTROY] = &C_WINAPI::OnDestroy;
}

void C_WINAPI::CreateApi()
{
    if (m_pApi == nullptr)
        m_pApi = shared_ptr<C_WINAPI>(new C_WINAPI());
}

shared_ptr<C_WINAPI> C_WINAPI::GetApi()
{
    return m_pApi;
}

void C_WINAPI::ReleaseApi()
{
    if(m_pApi != nullptr)
    {
    	m_pApi.reset();
    	m_pApi = nullptr;
    }
}

LRESULT C_WINAPI::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    return m_pApi->ApiProc(hWnd, message, wParam, lParam);
}

LRESULT C_WINAPI::ApiProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    if (message >= WM_USER || m_arMsgFuc[message] == nullptr)
        return DefWindowProc(hWnd, message, wParam, lParam);

    return (this->*m_arMsgFuc[message])(hWnd, wParam, lParam);
}

LRESULT C_WINAPI::OnPaint(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(hWnd, &ps);
    // TODO: ���⿡ hdc�� ����ϴ� �׸��� �ڵ带 �߰��մϴ�...
    EndPaint(hWnd, &ps);

    return 0;
}

LRESULT C_WINAPI::OnDestroy(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
    PostQuitMessage(0);
    return 0;
}
