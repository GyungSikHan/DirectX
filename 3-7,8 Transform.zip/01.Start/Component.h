#pragma once
#include "GameObject.h"

class Component
{
public:
	Component();
	virtual ~Component();

	virtual void Init() abstract;
	virtual void Update() abstract;

	shared_ptr<GameObject> GetGameObject() { return owner.lock(); }

protected:
	weak_ptr<GameObject> owner;
};
