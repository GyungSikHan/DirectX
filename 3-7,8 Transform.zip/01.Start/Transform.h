#pragma once
#include "Component.h"

class Transform : public Component
{
public:
	Transform();
	~Transform();

	void Init() override;
	void Update() override;

	Vec3 ToEulerAngles(Quaternion q);
	void UpdateTransform();

	//Local
	Vec3 GetLocalScale() { return localScale; }
	void SetLocalScale(const Vec3& Scale);
	Vec3 GetLocalRotation() { return localRotation; }
	void SetLocalRotation(const Vec3& Rotation);
	Vec3 GetLocalPosition() { return localPosition; }
	void SetLocalPosition(const Vec3& Position);

	//World
	Vec3 GetScale() { return scale; }
	void SetScale(const Vec3& Scale);
	Vec3 GetRotation() { return rotation; }
	void SetRotation(const Vec3& Rotation);
	Vec3 GetPosition() { return position; }
	void SetPosition(const Vec3& Position);

	Matrix GetWorldMatrix() { return matWorld; }

	//���� ����
	bool HasParnet() { return parent != nullptr; }
	shared_ptr<Transform> GetParent() { return parent; }
	void SetParent(shared_ptr<Transform> Parent) { parent = Parent; }

	const vector<shared_ptr<Transform>>& GetChildren() { return children; }
	void AddChild(shared_ptr<Transform> Child) { children.push_back(Child); }

private:
	Vec3 localScale = { 1.0f,1.0f,1.0f };
	Vec3 localRotation = {};
	Vec3 localPosition = {};

	Matrix matLocal = Matrix::Identity;
	Matrix matWorld = Matrix::Identity;

	//Cache
	Vec3 scale;
	Vec3 rotation;
	Vec3 position;

	Vec3 right;
	Vec3 up;
	Vec3 look;

private:
	shared_ptr<Transform> parent;
	vector<shared_ptr<Transform>> children;
};

