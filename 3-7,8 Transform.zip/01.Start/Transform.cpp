#include "pch.h"
#include "Transform.h"

Transform::Transform()
{
}

Transform::~Transform()
{
}

void Transform::Init()
{
	Component::Init();
}

void Transform::Update()
{
	Component::Update();
}

Vec3 Transform::ToEulerAngles(Quaternion q)
{
	Vec3 angles;

	// roll (x-axis rotation)
	double sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
	double cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
	angles.x = std::atan2(sinr_cosp, cosr_cosp);

	// pitch (y-axis rotation)
	double sinp = std::sqrt(1 + 2 * (q.w * q.y - q.x * q.z));
	double cosp = std::sqrt(1 - 2 * (q.w * q.y - q.x * q.z));
	angles.y = 2 * std::atan2(sinp, cosp) - 3.14159f / 2;

	// yaw (z-axis rotation)
	double siny_cosp = 2 * (q.w * q.z + q.x * q.y);
	double cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
	angles.z = std::atan2(siny_cosp, cosy_cosp);

	return angles;
}

void Transform::UpdateTransform()
{
	Matrix matscale = Matrix::CreateScale(localScale);
	Matrix matrotation = Matrix::CreateRotationX(localRotation.x);
	matrotation *= Matrix::CreateRotationY(localRotation.y);
	matrotation *= Matrix::CreateRotationZ(localRotation.z);
	Matrix mattranslation = Matrix::CreateTranslation(localPosition);

	matLocal = matscale * matrotation * mattranslation;

	if (HasParnet() == true)
		matWorld = matLocal * parent->GetWorldMatrix();
	else
		matWorld = matLocal;

	Quaternion quat;
	matWorld.Decompose(scale, quat, position);
	rotation = ToEulerAngles(quat);

	right = Vec3::TransformNormal(Vec3::Right, matWorld);
	up = Vec3::TransformNormal(Vec3::Up, matWorld);
	look = Vec3::TransformNormal(Vec3::Backward, matWorld);
	//Dx���� ���� ��ǥ�踦 ��������� SimpleMath�� ������ ��ǥ��� ������� �־� Forward�� �ƴ� Baclward�� �����

	//Children
	for (const shared_ptr<Transform>& c : children)
		c->UpdateTransform();
}

void Transform::SetLocalScale(const Vec3& Scale)
{
	localScale = Scale;
	UpdateTransform();
}

void Transform::SetLocalRotation(const Vec3& Rotation)
{
	localRotation = Rotation;
	UpdateTransform();
}

void Transform::SetLocalPosition(const Vec3& Position)
{
	localPosition = Position;
	UpdateTransform();
}

void Transform::SetScale(const Vec3& Scale)
{
	if (HasParnet() == true)
	{
		Vec3 parentScale = parent->GetScale();
		Vec3 tempScale = Scale;
		tempScale.x /= parentScale.x;
		tempScale.y /= parentScale.y;
		tempScale.z /= parentScale.z;

		SetLocalScale(tempScale);
	}
	else
		SetLocalScale(Scale);
}

void Transform::SetRotation(const Vec3& Rotation)
{
	if (HasParnet() == true)
	{
		Matrix worldToParentLocalMatrix = parent->GetWorldMatrix().Invert();

		Vec3 tempRotation;
		tempRotation.Transform(Rotation, worldToParentLocalMatrix);
		SetLocalRotation(tempRotation);
	}
	else
		SetLocalRotation(Rotation);
}

void Transform::SetPosition(const Vec3& Position)
{
	if (HasParnet() == true)
	{
		//�θ��� local���� world�� ���� ��ȯ ����� ������� ���ϸ� ���� ��ǥ�踦 �������� ������ ��ǥ��
		//�θ���ǥ�踦 �������� ��ǥ�� ��ȯ�� �� �ִ�
		Matrix worldToParentLocalMatrix = parent->GetWorldMatrix().Invert();

		Vec3 tempPosition;
		tempPosition.Transform(Position, worldToParentLocalMatrix);
		SetLocalPosition(tempPosition);
	}
	else
		SetLocalPosition(Position);
}
