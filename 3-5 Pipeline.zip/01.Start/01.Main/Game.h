#pragma once
#include "pch.h"

class Game
{
public:
	Game();
	~Game();

public:
	void Init(HWND hWnd);
	void Update();
	void Render();

private:
	HWND hwnd;
	shared_ptr<Graphics> graphics;

	shared_ptr<Pipeline> pipeline;

private:
	//Geometry
	shared_ptr<Geometry<VertexTextureData>> geometry;
	shared_ptr<VertexBuffer> vertexBuffer;
	shared_ptr<IndexBuffer> indexBuffer;
	shared_ptr<InputLayout> inputLayout;

	//VS
	shared_ptr<VertexShader> vertexShader;

	//RS
	shared_ptr<Rasterizer> rs;

	//PS
	shared_ptr<PixelShader> pixelShader;
	shared_ptr<SamplerState> sampler;

	//SRV
	//ShaderResourceView�� Shader�ȿ��� Texture�� �ش�
	shared_ptr<Texture> srv;

	shared_ptr<BlendState> blend;
	//[CPU<->GPU] [GPU <-> VRAM]

private:
	//SRT
	TransformData transformData;
	shared_ptr<ConstantBuffer<TransformData>> constantBuffer;

	Vec3 localPosition = {};
	Vec3 localRotation = {};
	Vec3 localScale = {1.0f,1.0f,1.0f};
};

