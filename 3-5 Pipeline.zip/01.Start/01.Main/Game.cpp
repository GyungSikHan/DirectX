#include "pch.h"
#include "Game.h"

Game::Game()
{
}

Game::~Game()
{
	graphics.reset();
	vertexBuffer.reset();
	indexBuffer.reset();
	inputLayout.reset();
	geometry.reset();
	vertexShader.reset();
	pixelShader.reset();
	sampler.reset();
	constantBuffer.reset();
	rs.reset();
	srv.reset();
	blend.reset();
}

void Game::Init(HWND hWnd)
{
	hwnd = hWnd;
	
	graphics = make_shared<Graphics>(hwnd);
	vertexBuffer = make_shared<VertexBuffer>(graphics->GetDevice());
	indexBuffer = make_shared<IndexBuffer>(graphics->GetDevice());
	inputLayout = make_shared<InputLayout>(graphics->GetDevice());
	geometry = make_shared<Geometry<VertexTextureData>>();
	vertexShader = make_shared<VertexShader>(graphics->GetDevice());
	pixelShader = make_shared<PixelShader>(graphics->GetDevice());
	sampler = make_shared<SamplerState>(graphics->GetDevice());
	constantBuffer = make_shared<ConstantBuffer<TransformData>>(graphics->GetDevice(), graphics->GetDeviceContext());
	rs = make_shared<Rasterizer>(graphics->GetDevice());
	srv = make_shared<Texture>(graphics->GetDevice());
	blend = make_shared<BlendState>(graphics->GetDevice());

	pipeline = make_shared<Pipeline>(graphics->GetDeviceContext());

	//Create Geometry
	{
		//VertexData - index
		GeometryHelper::CreateRectangle(geometry);
		//VertexBuffer
		vertexBuffer->Create<VertexTextureData>(geometry->GetVertices());
		//IndexBuffer
		indexBuffer->Create(geometry->GetIndices());
	}

	//Create VS
	vertexShader->Create(L"Default.hlsl", "VS", "vs_5_0");
	//CreateInputLayout
	inputLayout->Create(VertexTextureData::descs, vertexShader->GetBlob());
	//CreateRasterizerState
	rs->Create();
	//CreatePS
	pixelShader->Create(L"Default.hlsl", "PS", "ps_5_0");
	//CreateSamplerState
	sampler->Create();
	//CreateSRV
	srv->Create(L"IMG_0424.png");

	//CreateBlendState
	blend->Create();
	//CreateConstantBuffer
	constantBuffer->Create();
}

void Game::Update()
{
	//Scale Rotation Translation

	localPosition.x += 0.001f;

	Matrix scale = Matrix::CreateScale(localScale);
	Matrix rotation = Matrix::CreateRotationX(localRotation.x);
	rotation *= Matrix::CreateRotationY(localRotation.y);
	rotation *= Matrix::CreateRotationZ(localRotation.z);
	Matrix translation = Matrix::CreateTranslation(localPosition);

	Matrix world = scale * rotation * translation;
	transformData.World = world;

	constantBuffer->CopyData(transformData);
}

void Game::Render()
{
	graphics->RenderBegin();

	//IA - VS - RS - PS - OM
	{
		PipelineInfo info;

		info.inputLayout = inputLayout;
		info.vertexShader = vertexShader;
		info.pixelShader = pixelShader;
		info.rs = rs;
		info.blend = blend;

		pipeline->UpdatePipeline(info);

		pipeline->SetVertexBuffer(vertexBuffer);
		pipeline->SetIndexBuffer(indexBuffer);
		pipeline->ConstantBuffer(0, EVertexShader, constantBuffer);
		pipeline->SetTexture(0,EPixelShader,srv);
		//pipeline->SetSamplerState(0,EPixelShader,sampler);

		pipeline->DrawIndexed(geometry->GetIndexCount(), 0, 0);

		
	}
	
	graphics->RenderEnd();
}
