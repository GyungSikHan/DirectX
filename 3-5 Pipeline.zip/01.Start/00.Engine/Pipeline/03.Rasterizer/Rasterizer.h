#pragma once

class Rasterizer
{
public:
	Rasterizer(ComPtr<ID3D11Device> Device);
	~Rasterizer();

	void Create();
	ComPtr<ID3D11RasterizerState> GetComPtr() { return rs; }

private:
	ComPtr<ID3D11Device> device;
	ComPtr<ID3D11RasterizerState> rs;
};