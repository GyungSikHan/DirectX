#include "pch.h"
#include "Pipeline.h"

Pipeline::Pipeline(ComPtr<ID3D11DeviceContext> DeviceContext)
	:deviceContext(DeviceContext)
{
}

Pipeline::~Pipeline()
{
}

void Pipeline::UpdatePipeline(PipelineInfo info)
{
	//IA
	deviceContext->IASetInputLayout(info.inputLayout->GetComptr().Get());
	deviceContext->IASetPrimitiveTopology(info.topology);
	//VS
	if(info.vertexShader != nullptr)
		deviceContext->VSSetShader(info.vertexShader->GetComPtr().Get(), nullptr, 0);
	//RS
	if (info.rs != nullptr)
		deviceContext->RSSetState(info.rs->GetComPtr().Get());

	//PS
	if (info.pixelShader != nullptr)
		deviceContext->PSSetShader(info.pixelShader->GetComPtr().Get(), nullptr, 0);

	//OM
	if (info.blend != nullptr)
		deviceContext->OMSetBlendState(info.blend->GetComPtr().Get(), info.blend->GetBlendFactor(), info.blend->GetSampleMask());
}

void Pipeline::SetVertexBuffer(shared_ptr<VertexBuffer> buffer)
{
	uint32 stride = buffer->GetStride();
	uint32 offset = buffer->GetOffset();
	deviceContext->IASetVertexBuffers(0, 1, buffer->GetComPtr().GetAddressOf(), &stride,&offset);
}

void Pipeline::SetIndexBuffer(shared_ptr<IndexBuffer> buffer)
{
	deviceContext->IASetIndexBuffer(buffer->GetComPtr().Get(), DXGI_FORMAT_R32_UINT, 0);
}

void Pipeline::SetTexture(uint32 slot, uint32 scope, shared_ptr<Texture> texture)
{
	if (scope & EVertexShader)
		deviceContext->VSSetShaderResources(slot, 1, texture->GetComPtr().GetAddressOf());
	if (scope & EPixelShader)
		deviceContext->PSSetShaderResources(slot, 1, texture->GetComPtr().GetAddressOf());
}

void Pipeline::SetSamplerState(uint32 slot, uint32 scope, shared_ptr<SamplerState> sampler)
{
	if (scope & EVertexShader)
		deviceContext->VSSetSamplers(slot, 1, sampler->GetComPtr().GetAddressOf());
	if (scope & EPixelShader)
		deviceContext->PSSetSamplers(slot, 1, sampler->GetComPtr().GetAddressOf());
}

void Pipeline::Draw(uint32 vertexCount, uint32 startVertexLocation)
{
	deviceContext->Draw(vertexCount, startVertexLocation);
}

void Pipeline::DrawIndexed(uint32 indexCount, uint32 startIndexLocation, uint32 baseVertexLocation)
{
	deviceContext->DrawIndexed(indexCount, startIndexLocation, baseVertexLocation);
}
