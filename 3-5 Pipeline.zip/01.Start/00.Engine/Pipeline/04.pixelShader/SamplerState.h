#pragma once

class SamplerState
{
public:
	SamplerState(ComPtr<ID3D11Device> Device);
	~SamplerState();

	void Create();
	ComPtr<ID3D11SamplerState> GetComPtr() { return sampler; }

private:
	ComPtr<ID3D11Device> device;
	ComPtr<ID3D11SamplerState> sampler;
};