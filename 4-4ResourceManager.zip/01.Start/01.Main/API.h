#pragma once
#include "Game.h"

class C_WINAPI
{
private:
	C_WINAPI() = default;

public:
	void Init(HINSTANCE hInstance);
	void UpdateMsg();

private:
	void  InitMsgFunc();

public:
	static void CreateApi();
	static shared_ptr<C_WINAPI> GetApi();
	static void ReleaseApi();

private:
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT CALLBACK ApiProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

private:
	LRESULT OnPaint(HWND hWnd, WPARAM wParam, LPARAM lParam);
	LRESULT OnDestroy(HWND hWnd, WPARAM wParam, LPARAM lParam);

private:
	static shared_ptr<C_WINAPI> m_pApi;

private:
	HINSTANCE m_hInstance;
	HWND m_hWnd;

	LRESULT(C_WINAPI::* m_arMsgFuc[WM_USER])(HWND, WPARAM, LPARAM);
};