#include "pch.h"
#include "Game.h"
#include "Camera/Camera.h"
#include "SceneManager.h"
#include "Input/InputManager.h"
#include "Resource/ResourceMGR.h"
#include "Time/TimeManager.h"

unique_ptr<Game> GGame = make_unique < Game >();

Game::Game()
{
}

Game::~Game()
{
	graphics.reset();
	
}

void Game::Init(HWND hWnd)
{
	hwnd = hWnd;
	
	graphics = make_shared<Graphics>(hwnd);
	pipeline = make_shared<Pipeline>(graphics->GetDeviceContext());

	m_pInputMGR = make_shared<InputManager>();
	m_pInputMGR->Init(hwnd);

	m_pTimeMGR = make_shared<TimeManager>();
	m_pTimeMGR->Init();

	m_pScene = make_shared<SceneManager>(graphics);
	m_pScene->Init();

	m_pResourceMGR = make_shared<ResourceMGR>(graphics->GetDevice());
	m_pResourceMGR->Init();
	SCENE->LoadScene(L"Test");
}

void Game::Update()
{
	graphics->RenderBegin();
	TIME->Update();
	INPUT->Update();
	SCENE->Update();
	graphics->RenderEnd();
}

void Game::Render()
{
}
