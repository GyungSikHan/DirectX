#pragma once
#include "GameObject.h"

class InputManager;
class TimeManager;
class SceneManager;
class ResourceMGR;

class Game
{
public:
	Game();
	~Game();

public:
	void Init(HWND hWnd);
	void Update();
	void Render();

	shared_ptr<InputManager> GetInputMGR() {return m_pInputMGR;}
	shared_ptr<TimeManager> GetTimeMGR() { return m_pTimeMGR; }
	shared_ptr<SceneManager> GetSceneManager() { return m_pScene; }
	shared_ptr<ResourceMGR> GetResourceMGR() { return m_pResourceMGR; }
	shared_ptr<Pipeline> GetPipline() { return pipeline; }
private:
	HWND hwnd;
	shared_ptr<Graphics> graphics;
	shared_ptr<Pipeline> pipeline;

	shared_ptr<SceneManager> m_pScene;
	shared_ptr<InputManager> m_pInputMGR;
	shared_ptr<TimeManager> m_pTimeMGR;
	shared_ptr<ResourceMGR> m_pResourceMGR;
};

extern unique_ptr<Game> GGame;
