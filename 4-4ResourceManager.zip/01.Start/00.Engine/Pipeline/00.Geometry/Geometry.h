#pragma once

template<typename T>
class Geometry
{
public:
	Geometry(){};
	~Geometry(){};

	uint32 GetVertexCount() { return static_cast<uint32>(vertices.size()); }
	void* GetVertexData() { return vertices.data(); }
	const vector<T>& GetVertices() { return vertices; }

	uint32 GetIndexCount() { return static_cast<uint32>(indices.size()); }
	void* GetIndexData() { return indices.data(); }
	const vector<uint32>& GetIndices() { return indices; }

	//���Ϳ� �� �ϳ� �߰�
	void AddVertex(const T& vertex) { vertices.push_back(vertex); }
	//���� ���͸� ��ȸ�ϸ鼭 �ϳ��� �߰�
	void AddVertices(const vector<T>& Vertices) { vertices.insert(vertices.end(), Vertices.begin(), Vertices.end()); }
	//���͸� ��ä�� �߰�
	void SetVertices(const vector<T>& Vertices) { vertices = Vertices; }

	void AddIndex(uint32 index) { indices.push_back(index); }
	void AddIndices(const vector<uint32>& Indices) { indices.insert(indices.end(), Indices.begin(), Indices.end()); }
	void SetIndices(const vector<uint32>& Indices) { indices = Indices; }
private:
	vector<T> vertices;
	vector<uint32> indices;
};