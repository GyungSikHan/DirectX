#include "pch.h"
#include "ShaderBase.h"

ShaderBase::ShaderBase(ComPtr<ID3D11Device> Device)
	:device(Device), path(L"98.Shaders/")
{
}

ShaderBase::~ShaderBase()
{
}

void ShaderBase::Create(const wstring& Path, const string& Name, const string& version)
{
}

void ShaderBase::LoadShaderFormFile(const wstring& Path, const string& Name, const string& version)
{
	path += Path;
	name = Name;

	const uint32 compileFlag = D3DCOMPILE_DEBUG | D3DCOMPILE_SKIP_OPTIMIZATION;

	ComPtr<ID3DBlob> err;
	HRESULT hr = ::D3DCompileFromFile(
		path.c_str(),
		nullptr,
		D3D_COMPILE_STANDARD_FILE_INCLUDE,
		name.c_str(),
		version.c_str(),
		compileFlag, 0,
		blob.GetAddressOf(),
		err.GetAddressOf());
	if (FAILED(hr))
	{
		if (err)
			cout << "HLSL Compilation Error: " << (char*)err->GetBufferPointer() << endl;
		else 
			cout << "Unknown compilation error. HRESULT: " << hr << endl;
	}
	//CHECK(hr);
}
