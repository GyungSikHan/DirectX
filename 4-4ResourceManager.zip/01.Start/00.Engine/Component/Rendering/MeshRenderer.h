#pragma once

class MeshRenderer : public Component
{
	using Super = Component;

public:
	MeshRenderer(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext);
	~MeshRenderer();

	virtual void Update() override;

private:
	void Render(shared_ptr<Pipeline> pipeline);

private:
	ComPtr<ID3D11Device> m_pDevice;
	
	//Mesh
	shared_ptr<Geometry<VertexTextureData>> geometry;
	shared_ptr<VertexBuffer> vertexBuffer;
	shared_ptr<IndexBuffer> indexBuffer;

	//Material
	shared_ptr<InputLayout> inputLayout;
	shared_ptr<VertexShader> vertexShader;
	shared_ptr<Rasterizer> rs;
	shared_ptr<PixelShader> pixelShader;
	shared_ptr<Texture> srv;

	shared_ptr<SamplerState> sampler;
	shared_ptr<BlendState> blend;

private:

	//Camera
	CameraData m_cCameraData;
	shared_ptr<ConstantBuffer<CameraData>> m_pCameraBuffer;

	//SRT
	TransformData transformData;
	shared_ptr<ConstantBuffer<TransformData>> m_pTransformBuffer;
};

