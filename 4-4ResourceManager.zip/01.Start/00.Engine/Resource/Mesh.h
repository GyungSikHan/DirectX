#pragma once
#include "Resource/ResourceBase.h"

class Mesh : public ResourceBase
{
	using Super = ResourceBase;
public:
	Mesh();
	virtual ~Mesh();
};