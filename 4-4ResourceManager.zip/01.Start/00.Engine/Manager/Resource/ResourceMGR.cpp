#include "pch.h"
#include "Resource/ResourceMGR.h"
#include "Resource/Texture.h"
ResourceMGR::ResourceMGR(ComPtr<ID3D11Device> device)
	:m_pDevice(device), m_arResources()
{
}

void ResourceMGR::Init()
{
	CreateDefaultTexture();
	CreateDefaultMesh();
	CreateDefaultShader();
	CreateDefaultMaterial();
	CreateDefaultAnimation();
}

void ResourceMGR::CreateDefaultTexture()
{
	{
		shared_ptr<Texture> texture = make_shared<Texture>(m_pDevice);
		texture->GetName();
		texture->Create(L"Skeleton.png");
		Add(texture->GetName(), texture);
	}

}

void ResourceMGR::CreateDefaultMesh()
{
}

void ResourceMGR::CreateDefaultShader()
{
}

void ResourceMGR::CreateDefaultMaterial()
{
}

void ResourceMGR::CreateDefaultAnimation()
{
}
