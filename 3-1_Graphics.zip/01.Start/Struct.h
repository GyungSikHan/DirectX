#pragma once
#include "Types.h"

struct Vertex
{
	Vec3 position;
	//Color color;
	Vec2 uv;
};

struct TransformData
{
	Matrix World = Matrix::Identity;
	Matrix View = Matrix::Identity;
	Matrix Projection = Matrix::Identity;
};