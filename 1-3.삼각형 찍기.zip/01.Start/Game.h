#pragma once
#include "pch.h"

class Game
{
public:
	Game();
	~Game();

public:
	void Init(HWND hWnd);
	void Update();
	void Render();

private:
	void RenderBegin();
	void RenderEnd();

private:
	void CreateDeviceAndSpwaChain();
	void CreateRenderTargetView();
	void SetViewport();

private:
	void CreateGeometry();
	void CreateInputLayout();

	void CreateVS();
	void CreatePS();

	void LoadShaderFromFile(const wstring& path, const string& name, const string& version, ComPtr<ID3DBlob>& blob);

private:
	HWND hwnd;
	uint32 width = 0;
	uint32 height = 0;

private:
	//Device & SwapChain
	ComPtr<ID3D11Device> device{};
	ComPtr<ID3D11DeviceContext> deviceContext{};
	ComPtr<IDXGISwapChain> swapChain{};

	//RTV
	ComPtr<ID3D11RenderTargetView> renderTargetView;
	//ID3D11RenderTargetView �츮�� ���� �ĸ� ���۸� �����ϴ� ��ü

	//Misc
	//ȭ���� ũ�⸦ ��������
	D3D11_VIEWPORT viewport;
	float clearColor[4] = { 0.0f,0.0f ,0.0f ,0.0f };

private:
	//Geometry
	vector<Vertex> vertices;
	ComPtr<ID3D11Buffer> vertexBuffer{};
	ComPtr<ID3D11InputLayout> inputLayout{};

	//Shader�� �ε��ؼ� ������ �� ����ؾ� ��
	//VS
	ComPtr<ID3D11VertexShader> vertexShader{};
	ComPtr<ID3DBlob> vsBlob{};
	//PS
	ComPtr<ID3D11PixelShader> pixeShader{};
	ComPtr<ID3DBlob> psBlob{};
};

