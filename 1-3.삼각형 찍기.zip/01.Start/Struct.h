#pragma once
#include "Types.h"

struct Vertex
{
	Vec3 position;
	Color color;
};
