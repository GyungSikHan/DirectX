#pragma once
#include "pch.h"

class Game
{
public:
	Game();
	~Game();

public:
	void Init(HWND hWnd);
	void Update();
	void Render();

private:

	void CreateRasterizerState();
	void CreateSamplerState();
	void CreateBlendState();

	//SRV = Shader Resource View
	void CreateSRV();

private:
	HWND hwnd;
	shared_ptr<Graphics> graphics;

private:
	//Geometry
	shared_ptr<Geometry<VertexTextureData>> geometry;
	shared_ptr<VertexBuffer> vertexBuffer;
	shared_ptr<IndexBuffer> indexBuffer;
	shared_ptr<InputLayout> inputLayout;

	//VS
	shared_ptr<VertexShader> vertexShader;

	//RS
	ComPtr<ID3D11RasterizerState> rs;

	//PS
	shared_ptr<PixelShader> pixeShader{};

	//SRV
	//ShaderResourceView�� Shader�ȿ��� Texture�� �ش�
	shared_ptr<Texture> srv;

	ComPtr<ID3D11SamplerState> sampler;
	ComPtr<ID3D11BlendState> blend;
	//[CPU<->GPU] [GPU <-> VRAM]

private:
	//SRT
	TransformData transformData;
	shared_ptr<ConstantBuffer<TransformData>> constantBuffer;

	Vec3 localPosition = {};
	Vec3 localRotation = {};
	Vec3 localScale = {1.0f,1.0f,1.0f};
};

