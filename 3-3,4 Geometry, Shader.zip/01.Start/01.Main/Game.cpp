#include "pch.h"
#include "Game.h"

Game::Game()
{
}

Game::~Game()
{
}

void Game::Init(HWND hWnd)
{
	hwnd = hWnd;
	
	graphics = make_shared<Graphics>(hwnd);
	vertexBuffer = make_shared<VertexBuffer>(graphics->GetDevice());
	indexBuffer = make_shared<IndexBuffer>(graphics->GetDevice());
	inputLayout = make_shared<InputLayout>(graphics->GetDevice());
	geometry = make_shared<Geometry<VertexTextureData>>();
	vertexShader = make_shared<VertexShader>(graphics->GetDevice());
	pixeShader = make_shared<PixelShader>(graphics->GetDevice());
	constantBuffer = make_shared<ConstantBuffer<TransformData>>(graphics->GetDevice(), graphics->GetDeviceContext());
	srv = make_shared<Texture>(graphics->GetDevice());

	//Create Geometry
	{
		//VertexData - index
		GeometryHelper::CreateRectangle(geometry);
		//VertexBuffer
		vertexBuffer->Create<VertexTextureData>(geometry->GetVertices());
		//IndexBuffer
		indexBuffer->Create(geometry->GetIndices());
	}


	//Create VS
	vertexShader->Create(L"Default.hlsl", "VS", "vs_5_0");
	//CreateInputLayout
	inputLayout->Create(VertexTextureData::descs, vertexShader->GetBlob());
	CreateRasterizerState();
	CreateSamplerState();
	//CreatePS
	pixeShader->Create(L"Default.hlsl", "PS", "ps_5_0");
	//CreateSRV
	srv->Create(L"IMG_0424.png");

	CreateBlendState();

	constantBuffer->Create();
}

void Game::Update()
{
	//Scale Rotation Translation

	localPosition.x += 0.001f;

	Matrix scale = Matrix::CreateScale(localScale);
	Matrix rotation = Matrix::CreateRotationX(localRotation.x);
	rotation *= Matrix::CreateRotationY(localRotation.y);
	rotation *= Matrix::CreateRotationZ(localRotation.z);
	Matrix translation = Matrix::CreateTranslation(localPosition);

	Matrix world = scale * rotation * translation;
	transformData.World = world;

	constantBuffer->CopyData(transformData);
}

void Game::Render()
{
	graphics->RenderBegin();

	//IA - VS - RS - PS - OM
	{
		uint32 stride = sizeof(VertexTextureData);
		uint32 offset{};
		auto deviceContext = graphics->GetDeviceContext();
		//IA
		deviceContext->IASetVertexBuffers(0, 1, vertexBuffer->GetComPtr().GetAddressOf(), &stride, &offset);
		deviceContext->IASetIndexBuffer(indexBuffer->GetComPtr().Get(), DXGI_FORMAT_R32_UINT, 0);
		deviceContext->IASetInputLayout(inputLayout->GetComptr().Get());
		deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

		//VS
		deviceContext->VSSetShader(vertexShader->GetComPtr().Get(), nullptr, 0);
		deviceContext->VSSetConstantBuffers(0, 1, constantBuffer->GetComptr().GetAddressOf());

		//RS
		deviceContext->RSSetState(rs.Get());

		//PS
		deviceContext->PSSetShader(pixeShader->GetComPtr().Get(), nullptr, 0);
		deviceContext->PSSetShaderResources(0, 1, srv->GetComPtr().GetAddressOf());
		deviceContext->PSSetSamplers(0, 1, sampler.GetAddressOf());
		
		//OM
		deviceContext->OMSetBlendState(blend.Get(), nullptr,  0xFFFFFFFF);

		deviceContext->DrawIndexed(geometry->GetIndexCount(), 0, 0);
	}
	
	graphics->RenderEnd();
}

void Game::CreateRasterizerState()
{
	D3D11_RASTERIZER_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.FillMode = D3D11_FILL_SOLID;
	desc.CullMode = D3D11_CULL_BACK;

	desc.FrontCounterClockwise = false;
	
	HRESULT hr = graphics->GetDevice()->CreateRasterizerState(&desc, rs.GetAddressOf());
	CHECK(hr);
}

void Game::CreateSamplerState()
{
	CD3D11_SAMPLER_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.AddressU = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.BorderColor[0] = 1;
	desc.BorderColor[1] = 0;
	desc.BorderColor[2] = 0;
	desc.BorderColor[3] = 1;
	desc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	desc.MaxAnisotropy = 16;
	desc.MaxLOD = FLT_MAX;
	desc.MinLOD = FLT_MAX;
	desc.MipLODBias = 0.0f;

	graphics->GetDevice()->CreateSamplerState(&desc, sampler.GetAddressOf());
}

void Game::CreateBlendState()
{
	D3D11_BLEND_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.AlphaToCoverageEnable = false;
	desc.IndependentBlendEnable = false;

	desc.RenderTarget[0].BlendEnable = true;
	desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
	desc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
	desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
	desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
	desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
	desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

	HRESULT hr = graphics->GetDevice()->CreateBlendState(&desc, blend.GetAddressOf());
	CHECK(hr);
}