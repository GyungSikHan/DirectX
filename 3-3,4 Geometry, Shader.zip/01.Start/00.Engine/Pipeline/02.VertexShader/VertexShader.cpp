#include "pch.h"
#include "VertexShader.h"

VertexShader::VertexShader(ComPtr<ID3D11Device> Device)
:Super(Device)
{
}

VertexShader::~VertexShader()
{
}

void VertexShader::Create(const wstring& Path, const string& Name, const string& version)
{
	Shader::Create(Path, Name, version);

	LoadShaderFormFile(Path, Name, version);
	HRESULT hr = device->CreateVertexShader(blob->GetBufferPointer(),
		blob->GetBufferSize(), nullptr, vertexShader.GetAddressOf());
	CHECK(hr);
}