#pragma once

template<typename T>
class ConstantBuffer
{
public:
	ConstantBuffer(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext)
		:device(Device), deviceContext(DeviceContext)
	{
	}
	~ConstantBuffer(){}

	ComPtr<ID3D11Buffer> GetComptr() { return constantBuffer; }

	void Create()
	{
		D3D11_BUFFER_DESC desc{};
		ZeroMemory(&desc, sizeof(desc));
		desc.Usage = D3D11_USAGE_DYNAMIC;
		desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		desc.ByteWidth = sizeof(T);
		desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

		device->CreateBuffer(&desc, nullptr, constantBuffer.GetAddressOf());
		
	}

	void CopyData(const T& data)
	{
		D3D11_MAPPED_SUBRESOURCE sub{};
		ZeroMemory(&sub, sizeof(sub));

		deviceContext->Map(constantBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &sub);
		::memcpy(sub.pData, &data, sizeof(data));
		deviceContext->Unmap(constantBuffer.Get(), 0);
	}
private:
	ComPtr<ID3D11Device> device;
	ComPtr<ID3D11DeviceContext> deviceContext;
	ComPtr<ID3D11Buffer> constantBuffer;
};