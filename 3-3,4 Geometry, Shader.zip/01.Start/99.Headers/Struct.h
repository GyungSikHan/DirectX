#pragma once
#include "Types.h"

struct TransformData
{
	Matrix World = Matrix::Identity;
	Matrix View = Matrix::Identity;
	Matrix Projection = Matrix::Identity;
};