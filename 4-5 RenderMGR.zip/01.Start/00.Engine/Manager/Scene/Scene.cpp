#include "pch.h"
#include "Scene.h"

#include "GameObject.h"

void Scene::Awake()
{
	for (const shared_ptr<GameObject>& game : m_pGameObjects)
		game->Awake();
}

void Scene::Start()
{
	for (const shared_ptr<GameObject>& game : m_pGameObjects)
		game->Start();
}

void Scene::Update()
{
	for (const shared_ptr<GameObject>& game : m_pGameObjects)
		game->Update();
}

void Scene::LateUpdate()
{
	for (const shared_ptr<GameObject>& game : m_pGameObjects)
		game->LateUpdate();
}

void Scene::FixedUpdate()
{
	for (const shared_ptr<GameObject>& game : m_pGameObjects)
		game->FixedUpdate();
}

void Scene::AddGameObject(shared_ptr<GameObject> gameObject)
{
	m_pGameObjects.push_back(gameObject);
}

void Scene::RemoveGameObject(shared_ptr<GameObject> gameObject)
{
	vector<shared_ptr<GameObject>>::iterator iter = std::find(m_pGameObjects.begin(), m_pGameObjects.end(), gameObject);
	if (iter != m_pGameObjects.end())
		m_pGameObjects.erase(iter);
}
