#pragma once
class PixelShader : public ShaderBase
{
	using Super = ShaderBase;
public:
	PixelShader(ComPtr<ID3D11Device> Device);
	~PixelShader();

	ComPtr<ID3D11PixelShader> GetComPtr() { return pixelShader; }

	void Create(const wstring& Path, const string& Name, const string& version) override;

protected:
	ComPtr<ID3D11PixelShader> pixelShader{};
};