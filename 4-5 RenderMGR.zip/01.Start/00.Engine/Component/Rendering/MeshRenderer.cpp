#include "pch.h"
#include "MeshRenderer.h"
#include "Game.h"
#include "Camera/Camera.h"

MeshRenderer::MeshRenderer(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext)
: Super (ComponentType::MeshRenderer), m_pDevice(Device)
{
	//Create Geometry
	geometry = make_shared<Geometry<VertexTextureData>>();
	GeometryHelper::CreateRectangle(geometry);

	//VertexBuffer
	vertexBuffer = make_shared<VertexBuffer>(m_pDevice);
	vertexBuffer->Create<VertexTextureData>(geometry->GetVertices());

	//IndexBuffer
	indexBuffer = make_shared<IndexBuffer>(m_pDevice);
	indexBuffer->Create(geometry->GetIndices());

	//Create VS
	vertexShader = make_shared<VertexShader>(m_pDevice);
	vertexShader->Create(L"Default.hlsl", "VS", "vs_5_0");

	//CreateInputLayout
	inputLayout = make_shared<InputLayout>(m_pDevice);
	inputLayout->Create(VertexTextureData::descs, vertexShader->GetBlob());

	//CreatePS
	pixelShader = make_shared<PixelShader>(m_pDevice);
	pixelShader->Create(L"Default.hlsl", "PS", "ps_5_0");

	//CreateSRV
	srv = make_shared<Texture>(m_pDevice);
	srv->Create(L"IMG_1018.HEIC");
	
}

MeshRenderer::~MeshRenderer()
{
}

void MeshRenderer::Update()
{
	Component::Update();
}