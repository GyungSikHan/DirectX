#pragma once

class MeshRenderer : public Component
{
	using Super = Component;

public:
	MeshRenderer(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext);
	~MeshRenderer();

	virtual void Update() override;

public:
	shared_ptr<Geometry<VertexTextureData>> GetGeometry() { return geometry; }
	shared_ptr<VertexBuffer> GetVertexBuffer() { return vertexBuffer; }
	shared_ptr<IndexBuffer> GetIndexBuffer() { return indexBuffer; }

	shared_ptr<InputLayout> GetInputLayout() { return inputLayout; }
	shared_ptr<VertexShader> GetVertexShader() { return vertexShader; }
	shared_ptr<PixelShader> GetPixelShader() { return pixelShader; }
	shared_ptr<Texture> GetTexture() { return srv; }

private:
	ComPtr<ID3D11Device> m_pDevice;

	//Mesh
	shared_ptr<Geometry<VertexTextureData>> geometry;
	shared_ptr<VertexBuffer> vertexBuffer;
	shared_ptr<IndexBuffer> indexBuffer;

	//Material
	shared_ptr<InputLayout> inputLayout;
	shared_ptr<VertexShader> vertexShader;
	shared_ptr<PixelShader> pixelShader;
	shared_ptr<Texture> srv;
};

