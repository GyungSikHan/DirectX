#include "pch.h"
#include "Resource/Mesh.h"

Mesh::Mesh() : Super(ResourceType::Mesh)
{
}

Mesh::~Mesh()
{
}
