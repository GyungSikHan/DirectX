#pragma once
#include "Resource/ResourceBase.h"

class Animation : public ResourceBase
{
	using Super = ResourceBase;
public:
	Animation();
	virtual ~Animation();
};