#include "pch.h"
#include "Resource/Material.h"

Material::Material() : Super(ResourceType::Material)
{
}

Material::~Material()
{
}
