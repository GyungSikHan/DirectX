#include "pch.h"
#include "Resource/Shader.h"

Shader::Shader() : Super(ResourceType::Shader)
{
}

Shader::~Shader()
{
}
