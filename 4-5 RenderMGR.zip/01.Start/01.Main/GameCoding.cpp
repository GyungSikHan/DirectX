﻿// 01.Start.cpp : 애플리케이션에 대한 진입점을 정의합니다.
//
#include "pch.h"
#include "API.h"

LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    C_WINAPI::CreateApi();
    C_WINAPI::GetApi()->Init(hInstance);
    C_WINAPI::GetApi()->UpdateMsg();
    C_WINAPI::ReleaseApi();

    return 0;
}