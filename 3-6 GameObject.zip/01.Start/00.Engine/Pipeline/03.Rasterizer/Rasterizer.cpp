#include "pch.h"
#include "Rasterizer.h"

Rasterizer::Rasterizer(ComPtr<ID3D11Device> Device)
	:device(Device)
{
}

Rasterizer::~Rasterizer()
{
}

void Rasterizer::Create()
{
	D3D11_RASTERIZER_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.FillMode = D3D11_FILL_SOLID;
	desc.CullMode = D3D11_CULL_BACK;

	desc.FrontCounterClockwise = false;

	HRESULT hr = device->CreateRasterizerState(&desc, rs.GetAddressOf());
	CHECK(hr);
}
