#pragma once

struct PipelineInfo
{
	shared_ptr<InputLayout> inputLayout;
	shared_ptr<VertexShader> vertexShader;
	shared_ptr<PixelShader> pixelShader;
	shared_ptr<Rasterizer> rs;
	shared_ptr<BlendState> blend;
	D3D11_PRIMITIVE_TOPOLOGY topology = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
};

class Pipeline
{
public:
	Pipeline(ComPtr<ID3D11DeviceContext> DeviceContext);
	~Pipeline();

	//�ʼ������� ���� ���ҽ��� DeviceContext�� ����
	void UpdatePipeline(PipelineInfo info);

	//�ʼ������� �ʰ� �ʿ��Ҷ� ���� ���ҽ��� DeviceContext�� ����
	void SetVertexBuffer(shared_ptr<VertexBuffer> buffer);
	void SetIndexBuffer(shared_ptr<IndexBuffer> buffer);
	template<typename T>
	void ConstantBuffer(uint32 slot, uint32 scope, shared_ptr<ConstantBuffer<T>> buffer)
	{
		if (scope & EVertexShader)
			deviceContext->VSSetConstantBuffers(slot, 1, buffer->GetComptr().GetAddressOf());
		if (scope & EPixelShader)
			deviceContext->PSSetConstantBuffers(slot, 1, buffer->GetComptr().GetAddressOf());
	}
	void SetTexture(uint32 slot, uint32 scope, shared_ptr<Texture> texture);
	void SetSamplerState(uint32 slot, uint32 scope, shared_ptr<SamplerState> sampler);

	void Draw(uint32 vertexCount, uint32 startVertexLocation);
	void DrawIndexed(uint32 indexCount, uint32 startIndexLocation, uint32 baseVertexLocation);

private:
	ComPtr<ID3D11DeviceContext> deviceContext;
};