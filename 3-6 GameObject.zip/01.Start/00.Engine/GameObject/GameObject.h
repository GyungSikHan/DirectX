#pragma once

class GameObject
{
public:
	GameObject(ComPtr<ID3D11Device> Device, ComPtr<ID3D11DeviceContext> DeviceContext);
	~GameObject();

	void Update();
	void Rneder(shared_ptr<Pipeline> Pipeline);

private:
	ComPtr<ID3D11Device> device;

	//Geometry
	shared_ptr<Geometry<VertexTextureData>> geometry;
	shared_ptr<VertexBuffer> vertexBuffer;
	shared_ptr<IndexBuffer> indexBuffer;
	shared_ptr<InputLayout> inputLayout;
	//VS
	shared_ptr<VertexShader> vertexShader;
	//RS
	shared_ptr<Rasterizer> rs;
	//PS
	shared_ptr<PixelShader> pixelShader;
	shared_ptr<SamplerState> sampler;
	//SRV
	shared_ptr<Texture> srv;

	shared_ptr<BlendState> blend;

private:
	//SRT
	TransformData transformData;
	shared_ptr<ConstantBuffer<TransformData>> constantBuffer;

	Vec3 localPosition = {};
	Vec3 localRotation = {};
	Vec3 localScale = { 1.0f,1.0f,1.0f };
};


