#include "pch.h"
#include "Game.h"

Game::Game()
{
}

Game::~Game()
{
	graphics.reset();
	/*vertexBuffer.reset();
	indexBuffer.reset();
	inputLayout.reset();
	geometry.reset();
	vertexShader.reset();
	pixelShader.reset();
	sampler.reset();
	constantBuffer.reset();
	rs.reset();
	srv.reset();
	blend.reset();*/
}

void Game::Init(HWND hWnd)
{
	hwnd = hWnd;
	
	graphics = make_shared<Graphics>(hwnd);
	pipeline = make_shared<Pipeline>(graphics->GetDeviceContext());
	gameObject = make_shared<GameObject>(graphics->GetDevice(), graphics->GetDeviceContext());
}

void Game::Update()
{
	gameObject->Update();
}

void Game::Render()
{
	graphics->RenderBegin();

	gameObject->Rneder(pipeline);
	
	graphics->RenderEnd();
}
